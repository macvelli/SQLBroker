package org.sqlbroker.util;

/**
 * TODO Need a JDBC URL Builder that makes it super easy using enum values (i.e. jTDS), strings (schema name, port number, username, password, etc), and key-value pairs for optional config settings to build up a connection string
 * 
 * @author esmith
 * @version 1.0
 */
public class JdbcURLBuilder {

}	// End JdbcURLBuilder
