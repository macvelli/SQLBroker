package root.thread;

import root.data.structure.ListArray;
import root.pool.Factory;
import root.pool.Pool;

/**
 * 
 * @author esmith
 */
public final class ThreadPool {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final Pool<PooledThread>		pool;

	private final ListArray<PooledThread>	tasks;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ThreadPool(final int capacity) {
		this(capacity, Thread.NORM_PRIORITY);
	}

	public ThreadPool(final int capacity, final int priority) {
		switch (priority) {
			case Thread.NORM_PRIORITY	:
			case Thread.MAX_PRIORITY	:
			case Thread.MIN_PRIORITY	:	break;
			default						:	throw new IllegalArgumentException("Invalid thread priority");
		}

		pool = new Pool<>(capacity, new PooledThreadFactory(priority));
		tasks = new ListArray<>(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void close() {
		for (PooledThread t : tasks) {
			t.running = false;
			t.interrupt();
		}
	}

	public final void execute(final Runnable r) {
		final PooledThread t;

		try { t = pool.acquire(); } catch (Exception e) {
			throw new IllegalStateException(e);
		}

		t.sync.lock();
		try {
			t.activity = r;
			t.sync.signal();
		} finally {
			t.sync.unlock();
		}
	}

	public final void execute(final Runnable[] l) {
		for (Runnable r : l) {
			execute(r);
		}
	}

	public final void execute(final Iterable<? extends Runnable> l) {
		for (Runnable r : l) {
			execute(r);
		}
	}

	/**
	 * Returns the maximum amount of time in milliseconds the pool will wait
	 * for a task to free up before erroring out.
	 * 
	 * @return the maximum amount of time the pool will wait for a task.
	 */
	public final long getMaxWait() {
		return pool.getMaxWait();
	}

	/**
	 * Sets  the maximum amount of time in milliseconds the pool will wait
	 * for a task to free up before erroring out. A value less than or
	 * equal to zero is ignored and the pool will wait indefinitely.
	 * 
	 * @param maxWait The maximum amount of time the pool will wait for a task.
	 */
	public final void setMaxWait(final int maxWait) {
		pool.setMaxWait(maxWait);
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	/**
	 * Defines the {@link Factory} implementation used by the {@link Pool} for
	 * the {@link PooledThread} objects.
	 * 
	 * @author esmith
	 */
	private final class PooledThreadFactory implements Factory<PooledThread> {

		private final int priority;

		private PooledThreadFactory(final int priority) {
			this.priority = priority;
		}

		public final PooledThread create() {
			final PooledThread task = new PooledThread();
			task.setPriority(priority);
			tasks.add(task);
			task.start();
			return task;
		}

		public final void destroy(final PooledThread task) {
			// No-op
		}

		public final boolean validate(final PooledThread task) {
			return true;
		}

	}	// End PooledThreadFactory

	private final class PooledThread extends Thread {

		private boolean running;

		private Runnable activity;

		private final Sync sync;

		private PooledThread() {
			sync = new Sync();
			running = true;
		}

		public void run() {
			sync.lock();
			while (running) {
				try {
					while (activity == null) {
						sync.await();
					}

					activity.run();
				} catch (InterruptedException e) {
				} catch (Throwable t) {
					// TODO: Convert this to using root.log.Log
					System.err.println("Exception occurred while running activity: " + t);
				} finally {
					activity = null;
					pool.abandon(this);
				}
			}
			sync.unlock();
		}

	}	// End PooledThread

}
