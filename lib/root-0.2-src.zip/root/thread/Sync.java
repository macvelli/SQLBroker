package root.thread;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Sync {

	private final Condition		cond;
	private final ReentrantLock	lock;

	public Sync() {
		lock = new ReentrantLock();
		cond = lock.newCondition();
	}

	public void await() throws InterruptedException {
		cond.await();
	}

	public long awaitNanos(long timeout) throws InterruptedException {
		return cond.awaitNanos(timeout);
	}

	public void lock() {
		lock.lock();
	}

	public void signal() {
		cond.signal();
	}

	public void signalAll() {
		cond.signalAll();
	}

	public void unlock() {
		lock.unlock();
	}

}
