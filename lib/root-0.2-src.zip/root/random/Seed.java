package root.random;

public class Seed {

	private final byte[] seed;

	public Seed(final byte[] seed) {
		this.seed = seed;
	}

	public byte getByte(final int offset) {
		return seed[offset];
	}

	public byte[] getBytes() {
		return seed;
	}

	public int getInt(final int offset) {
		return seed[offset] << 24 | (seed[offset+1] & 0xFF) << 16 | (seed[offset+2] & 0xFF) << 8 | (seed[offset+3] & 0xFF);
	}

}	// End Seed
