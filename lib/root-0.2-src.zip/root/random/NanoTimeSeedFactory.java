package root.random;

public class NanoTimeSeedFactory implements SeedFactory {

	public Seed create(final int numBytes) {
		final byte[] seed = new byte[numBytes];
		long nanoTime = 0;

		for (int i=0; i < numBytes; nanoTime >>>= 8) {
			if (nanoTime == 0) {
				nanoTime = System.nanoTime();
			}
			seed[i++] = (byte) nanoTime;
		}

		return new Seed(seed);
	}

}	// End NanoTimeSeedFactory
