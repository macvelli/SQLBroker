package root.random;

import java.util.Random;

public class RandomSeedFactory implements SeedFactory {

	private static final Random seedSource = new Random();

	public Seed create(final int numBytes) {
		final byte[] seed = new byte[numBytes];
		seedSource.nextBytes(new byte[numBytes]);
		return new Seed(seed);
	}

}	// End RandomSeedFactory
