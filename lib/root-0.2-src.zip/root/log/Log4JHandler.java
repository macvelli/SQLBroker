package root.log;

import java.util.logging.ErrorManager;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;

import root.data.structure.MapBuilder;
import root.data.structure.MapImmutable;

public final class Log4JHandler extends Handler {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final String FQCN = Log4JHandler.class.getName();

	private static final MapImmutable<Level, org.apache.log4j.Level> levelMap = new MapBuilder<Level, org.apache.log4j.Level>()
			.put(Level.ALL, org.apache.log4j.Level.ALL)
			.put(Level.CONFIG, org.apache.log4j.Level.INFO)
			.put(Level.FINE, org.apache.log4j.Level.DEBUG)
			.put(Level.FINER, org.apache.log4j.Level.DEBUG)
			.put(Level.FINEST, org.apache.log4j.Level.TRACE)
			.put(Level.INFO, org.apache.log4j.Level.INFO)
			.put(Level.OFF, org.apache.log4j.Level.OFF)
			.put(Level.SEVERE, org.apache.log4j.Level.ERROR)
			.put(Level.WARNING, org.apache.log4j.Level.WARN)
			.build();

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void close() throws SecurityException {}

	@Override
	public final void flush() {}

	@Override
	public final void publish(final LogRecord record) {
		try {
			final Logger logger = Logger.getLogger(record.getLoggerName());
			logger.callAppenders(new LoggingEvent(FQCN, logger, record.getMillis(), levelMap.get(record.getLevel(), org.apache.log4j.Level.INFO), record.getMessage(), record.getThrown()));
		} catch (Exception e) {
			reportError(null, e, ErrorManager.GENERIC_FAILURE);
		}
	}

}
