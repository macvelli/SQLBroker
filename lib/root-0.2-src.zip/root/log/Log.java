package root.log;

import java.io.InputStream;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import root.lang.ParamStr;
import root.util.Properties;
import root.util.Safe;

public class Log {
// TODO: Tracking entering and exiting a method is classic AOP...come up with such to not just track entering and exiting but also log what is being passed into the method and also what the return value is, if any
// TODO: How to dynamically change logging levels per HTML request?  Filter?  Promote in the beginning and restore at the end?  Works on root logger and its dumb derivatives but what about a logger with its own level?
// TODO: Next, need to come up with a standard way to glean configuration data from the properties file
// TODO: Extractable implementations...
//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Static Artifacts ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static void init(final String propertiesFile) {
		final InputStream in = Properties.getInputStream(propertiesFile);

		if (in == null)
			throw new RuntimeException("Cannot find " + propertiesFile + " on either the classpath or the file system");

		try {
			LogManager.getLogManager().readConfiguration(in);
		} catch (Exception e) {
			throw new RuntimeException("Error during log initialization: " + propertiesFile, e);
		} finally {
			Safe.close(in);
		}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~ End Static Artifacts ~~~~~~~~~~~~~~~~~~~~~~~~~~

	private final Logger logger;

	public Log(final Class<?> clazz) {
		logger = Logger.getLogger(clazz.getName());
	}

	public Log(final String name) {
		logger = Logger.getLogger(name);
	}

	public void close() {
		for (Handler h : logger.getHandlers())
			try { h.close(); } catch (Throwable t) {}
	}

	public void setHandler(final Handler h, final Formatter f) {
		for (Handler i : logger.getHandlers())
			logger.removeHandler(i);

		h.setFormatter(f);
		logger.addHandler(h);		
	}

	public void debug(final String msg) {
		if (logger.isLoggable(Level.FINE))
			log(new LogRecord(Level.FINE, msg));
	}

	public void debug(final String msg, final Object... params) {
		if (logger.isLoggable(Level.FINE))
			log(new LogRecord(Level.FINE, ParamStr.format(msg, params)));
	}

	public void debug(final String msg, final Throwable t) {
		if (logger.isLoggable(Level.FINE)) {
			final LogRecord lr = new LogRecord(Level.FINE, msg);
			lr.setThrown(t);
			log(lr);
		}
	}

	public void error(final String msg) {
		if (logger.isLoggable(Level.SEVERE))
			log(new LogRecord(Level.SEVERE, msg));
	}

	public void error(final String msg, final Object... params) {
		if (logger.isLoggable(Level.SEVERE))
			log(new LogRecord(Level.SEVERE, ParamStr.format(msg, params)));
	}

	public void error(final String msg, final Throwable t) {
		if (logger.isLoggable(Level.SEVERE)) {
			final LogRecord lr = new LogRecord(Level.SEVERE, msg);
			lr.setThrown(t);
			log(lr);
		}
	}

	public void info(final String msg) {
		if (logger.isLoggable(Level.INFO))
			log(new LogRecord(Level.INFO, msg));
	}

	public void info(final String msg, final Object... params) {
		if (logger.isLoggable(Level.INFO))
			log(new LogRecord(Level.INFO, ParamStr.format(msg, params)));
	}

	public void info(final String msg, final Throwable t) {
		if (logger.isLoggable(Level.INFO)) {
			final LogRecord lr = new LogRecord(Level.INFO, msg);
			lr.setThrown(t);
			log(lr);
		}
	}

	public void trace(final String msg) {
		if (logger.isLoggable(Level.FINEST))
			log(new LogRecord(Level.FINEST, msg));
	}

	public void trace(final String msg, final Object... params) {
		if (logger.isLoggable(Level.FINEST))
			log(new LogRecord(Level.FINEST, ParamStr.format(msg, params)));
	}

	public void trace(final String msg, final Throwable t) {
		if (logger.isLoggable(Level.FINEST)) {
			final LogRecord lr = new LogRecord(Level.FINEST, msg);
			lr.setThrown(t);
			log(lr);
		}
	}

	public void warn(final String msg) {
		if (logger.isLoggable(Level.WARNING))
			log(new LogRecord(Level.WARNING, msg));
	}

	public void warn(final String msg, final Object... params) {
		if (logger.isLoggable(Level.WARNING))
			log(new LogRecord(Level.WARNING, ParamStr.format(msg, params)));
	}

	public void warn(final String msg, final Throwable t) {
		if (logger.isLoggable(Level.WARNING)) {
			final LogRecord lr = new LogRecord(Level.WARNING, msg);
			lr.setThrown(t);
			log(lr);
		}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~ Protected Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	protected void log(final LogRecord lr) {
		lr.setLoggerName(logger.getName());

		Logger l;
		for (l = logger; l != null; l = l.getParent())
			if (l.getResourceBundleName() != null) {
				lr.setResourceBundleName(l.getResourceBundleName());
				lr.setResourceBundle(l.getResourceBundle());
				break;
			}

		if (logger.getFilter() == null || logger.getFilter().isLoggable(lr)) {
			int i;
			Handler[] handlers;

			for (l = logger; l != null; l = l.getParent()) {
				handlers = l.getHandlers();
				if (handlers != null && handlers.length > 0)
					for (i = 0; i < handlers.length; i++)
						handlers[i].publish(lr);

			    if (!l.getUseParentHandlers())
			    	break;
			}
		}
	}

}	// End Log
