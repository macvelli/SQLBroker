package root.cache;

class Item<K, V> implements java.io.Serializable {

	private static final long serialVersionUID = 4218605306502444225L;

	K			key;
	volatile V 	value;
	int			index;
	Item<K, V>	next;
	Item<K, V>	prev;
	Item<K, V>	sNext;
	Item<K, V>	sPrev;

	Item(final K key, final V value, final int index, final Item<K, V> next) {
		this.key = key;
		this.value = value;
		this.index = index;
		this.sNext = next;
		this.sPrev = null;

		if (next != null)
			next.sPrev = this;
	}

}	// End Item
