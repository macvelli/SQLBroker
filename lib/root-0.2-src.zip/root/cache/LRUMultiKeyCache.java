package root.cache;

import root.util.Safe;

// TODO: This has serious issues all around...probably get LRUCache tightened up and then completely redo this class based upon the tight LRUCache implementation
public class LRUMultiKeyCache<K, V> implements Cache<K[], V>, java.io.Serializable {

	private static final long serialVersionUID = -6971593228105125523L;

	private int				size;
	private Item<K[], V>	head;
	private Item<K[], V>	tail;

	private final int				capacity;
	private final Item<K[], V>[]	cache;

	@SuppressWarnings("unchecked")
	public LRUMultiKeyCache(final int capacity) {
		this.capacity = capacity;
		cache = new Item[capacity + (capacity >> 1)];
	}

	public void clear() {
		Item<K[], V> e, next;

		// 1. Clear all entries from the cache
		for (int i=0; i < cache.length; i++) {
			for (e = cache[i]; e != null; e = next) {
				next = e.sNext;
				e.key = null;
				e.value = null;
				e.sNext = null;
			}
			cache[i] = null;
		}

		// 2. Clear all entries from the list
		for (; head != null; head = next) {
			next = head.next;
			head.prev = null;
			head.next = null;
		}
		tail = null;

		size = 0;
	}

	public V get(final K[] key) {
		for (Item<K[], V> e = cache[Safe.hashCode(key) % cache.length]; e != null; e = e.sNext)
			if (Safe.equals(e.key, key)) {
				// Move the item to the tail of the list
				if (tail != e) {
					if (head == e)
						head = head.next;
					else {
						e.prev.next = e.next;
						e.next.prev = e.prev;
					}

					tail.next = e;
					e.prev = tail;
					e.next = null;
					tail = e;
				}

				return e.value;
			}

		return null;
	}

	public V put(final K[] key, final V value) {
		final int i = Safe.hashCode(key) % cache.length;

		// 1. Check to see if key already mapped to cache
		for (Item<K[], V> e = cache[i]; e != null; e = e.sNext)
			if (Safe.equals(e.key, key)) {
				final V v = e.value;
				e.value = value;
				return v;
			}

		// 2. Recycle LRU item if cache is full
		if (size == capacity) {
			final V v = head.value;
			recycle(key, value, i);
			return v;
		}

		// 3. Otherwise create new cache item and append it to the list tail
		final Item<K[], V> e = new Item<K[], V>(key, value, i, cache[i]);
		cache[i] = e;
		size++;

		if (tail == null)
			head = e;
		else {
			tail.next = e;
			e.prev = tail;
		}
		tail = e;

		return null;
	}

	public V remove() {
		return (head == null) ? null : remove(head.key);
	}

	public V remove(final K[] key) {
		final int i = Safe.hashCode(key) % cache.length;

		for (Item<K[], V> e = cache[i], prev = null; e != null; prev = e, e = e.sNext)
			if (Safe.equals(e.key, key)) {
				if (prev == null)
					cache[i] = e.sNext;
				else
					prev.sNext = e.sNext;

				// Remove item from the list
				if (head == tail) {
					head = null;
					tail = null;
				} else if (head == e) {
					head = head.next;
					head.prev = null;
				} else if (tail == e) {
					tail = tail.prev;
					tail.next = null;
				} else {
					e.prev.next = e.next;
					e.next.prev = e.prev;
				}

				final V v = e.value;
				e.key = null;
				e.value = null;
				e.sNext = null;
				e.next = null;
				e.prev = null;
				size--;

				return v;
			}

		return null;
	}

	public int size() {
		return size;
	}

//	**************************** Private Methods *****************************

	private void recycle(final K[] key, final V value, final int newIndex) {
		// 1. Remove the head item from the cache table
		Item<K[], V> reuse = cache[head.index], prev = null;
		while (reuse != head) {
			prev = reuse;
			reuse = reuse.sNext;
		}

		if (prev == null)
			cache[head.index] = reuse.sNext;
		else
			prev.sNext = reuse.sNext;

		// 2. Remove item from the head of the list
		head = head.next;
		head.prev = null;

		// 3. Attach reused item to the list tail
		tail.next = reuse;
		reuse.prev = tail;
		reuse.next = null;
		tail = reuse;

		// 4. Populate reused item with new cached data
		reuse.key = key;
		reuse.value = value;
		reuse.index = newIndex;
		reuse.sNext = cache[newIndex];
		cache[newIndex] = reuse;
	}

}	// End LRUCache
