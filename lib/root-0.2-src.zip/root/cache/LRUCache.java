package root.cache;

import java.util.concurrent.locks.ReentrantLock;

import root.util.Safe;

// TODO: This class probably has many threading issues with respect to the cache table and LRU list
// TODO: Think about a cache.update() method and what that should do
// TODO: Also think about an LRUCache<K, List<V>> implementation that caches lists of data (or Sets for that matter)
// TODO: What about cache synchronization across servers?
public class LRUCache<K, V> implements Cache<K, V>, java.io.Serializable {

	private static final long serialVersionUID = -6971593228105125523L;

	private Item<K, V>				head;
	private Item<K, V>				tail;
	private transient volatile int	size;

	private final int			capacity;
	private final Item<K, V>[]	cache;
	private final ReentrantLock	list;

	@SuppressWarnings("unchecked")
	public LRUCache(final int capacity) {
		this.capacity = capacity;
		cache = new Item[capacity + (capacity >> 1)];
		list = new ReentrantLock();
	}

	/* (non-Javadoc)
	 * @see root.cache.Cache#clear()
	 */
	public void clear() {
		Item<K, V> e, next;

		if (size != 0) {
			// 1. Clear all entries from the cache
			for (int i=0, j=0; j < capacity; i++) {
				for (e = cache[i]; e != null; j++, e = next) {
					next = e.sNext;
					e.key = null;
					e.value = null;
					e.sNext = null;
					e.sPrev = null;
				}
				cache[i] = null;
			}

			list.lock();
			try {
				// 2. Clear all entries from the list
				for (; head != null; head = next) {
					next = head.next;
					head.prev = null;
					head.next = null;
				}
				tail = null;
			} finally {
				list.unlock();
			}
		}
	}

	/* (non-Javadoc)
	 * @see root.cache.Cache#get(K)
	 */
	public V get(final K key) {
		for (Item<K, V> e = cache[Safe.hashCode(key) % cache.length]; e != null; e = e.sNext) {
			if (Safe.equals(e.key, key)) {
				final V v = e.value;
				list.lock();
				try {
					// Move the item to the tail of the list
					if (tail != e) {
						if (head == e)
							head = head.next;
						else {
							e.prev.next = e.next;
							e.next.prev = e.prev;
						}

						tail.next = e;
						e.prev = tail;
						e.next = null;
						tail = e;
					}
				} finally {
					list.unlock();
				}

				return v;
			}
		}

		return null;
	}

	/* (non-Javadoc)
	 * @see root.cache.Cache#put(K, V)
	 */
	public V put(final K key, final V value) {
		Item<K, V> e;
		final int i = Safe.hashCode(key) % cache.length;

		// TODO: How to factor all of this out and still have the original intent intact?
		// 1. Check to see if key already mapped to cache
		for (e = cache[i]; e != null; e = e.sNext) {
			if (Safe.equals(e.key, key)) {
				final V v = e.value;
				e.value = value;
				return v;
			}
		}

		// 2. Recycle LRU item if cache is full
		if (size == capacity)
			return recycle(key, value, i);

		// 3. Otherwise create new cache item and append it to the list tail
		e = cache[i] = new Item<K, V>(key, value, i, cache[i]);

		list.lock();
		try {
			if (tail == null)
				head = e;
			else {
				tail.next = e;
				e.prev = tail;
			}
			tail = e;
			size++;
		} finally {
			list.unlock();
		}

		return null;
	}

	/* (non-Javadoc)
	 * @see root.cache.Cache#remove()
	 */
	public V remove() {
		Item<K, V> e;

		// 1. If the cache is empty return null
		if (size == 0)
			return null;

		list.lock();
		try {
			// 2. Save off the head value
			e = head;

			// 3. Remove the head item from the map
			if (head.sPrev == null)
				cache[head.index] = head.sNext;
			else
				head.sPrev.sNext = head.sNext;

			if (head.sNext != null)
				head.sNext.sPrev = head.sPrev;

			// 4. Remove the head item from the list
			if (head == tail) {
				head = null;
				tail = null;
			} else
				head = head.next;

			size--;
		} finally {
			list.unlock();
		}

		final V v = e.value;

		e.key = null;
		e.sNext = null;
		e.next = null;
		e.prev = null;
		e.value = null;
		e = null;

		return v;
	}

	/* (non-Javadoc)
	 * @see root.cache.Cache#remove(K)
	 */
	public V remove(final K key) {
		Item<K, V> e;
		final int i = Safe.hashCode(key) % cache.length;

		for (e = cache[i]; e != null; e = e.sNext)
			if (Safe.equals(e.key, key)) {
				final V v = e.value;

				if (e.sPrev == null)
					cache[i] = e.sNext;
				else
					e.sPrev.sNext = e.sNext;

				if (e.sNext != null)
					e.sNext.sPrev = e.sPrev;

				list.lock();
				try {
					// Remove item from the list
					if (head == tail) {
						head = null;
						tail = null;
					} else if (head == e) {
						head = head.next;
						head.prev = null;
					} else if (tail == e) {
						tail = tail.prev;
						tail.next = null;
					} else {
						e.prev.next = e.next;
						e.next.prev = e.prev;
					}

					size--;
				} finally {
					list.unlock();
				}

				e.key = null;
				e.sNext = null;
				e.next = null;
				e.prev = null;
				e.value = null;
				e = null;
				return v;
			}

		return null;
	}

	public int size() {
		return size;
	}

//	**************************** Private Methods *****************************

	private V recycle(final K key, final V value, final int newIndex) {
		// TODO: Ok this is going to have some threading issues because it doesn't lock...when and where to lock?
		final V v = head.value;

		// 1. Remove the head item from the cache table
		if (head.sPrev == null)
			cache[head.index] = head.sNext;
		else
			head.sPrev.sNext = head.sNext;

		if (head.sNext != null)
			head.sNext.sPrev = head.sPrev;

		// 2. Remove item from the head of the list
		final Item<K, V> reuse = head;
		head = head.next;
		head.prev = null;

		// 3. Attach reused item to the list tail
		tail.next = reuse;
		reuse.prev = tail;
		reuse.next = null;
		tail = reuse;

		// 4. Populate reused item with new cached data
		reuse.key = key;
		reuse.index = newIndex;
		reuse.sNext = cache[newIndex];
		if (reuse.sNext != null)
			reuse.sNext.sPrev = reuse;
		cache[newIndex] = reuse;
		reuse.value = value;

		return v;
	}

}	// End LRUCache
