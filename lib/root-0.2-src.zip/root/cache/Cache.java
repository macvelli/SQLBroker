package root.cache;

public interface Cache<K, V> {

	public void clear();

	public V get(final K key);

	public V put(final K key, final V value);

	public V remove();

	public V remove(final K key);

	public int size();

}	// End Cache