package root.finance;

import root.lang.CharArrayBuilder;
import root.lang.Characters;
import root.lang.Extractable;

/**
 * The Money class is built for only working with exact monetary values. The
 * amount is stored internally as an <code>int</code> to preserve data
 * integrity when performing financial calculations.  The minimum value of a
 * Money object is -21,474,836.48 while the maximum value is 21,474,836.47
 * (inclusive).  Safe to replace up to DECIMAL(9,2) with INTEGER in database
 * applications.
 * 
 * http://java-performance.info/bigdecimal-vs-double-in-financial-calculations/
 * 
 * @author esmith
 */
public final class Money implements Comparable<Money>, Extractable {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 4908171716774769169L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	// TODO: For budget purposes, as well as data deduplication, do we need a compact "Date" class that is simply just the month and year?  Then we could store this value as part of a primary key (along with user ID) which is then referenced across all entries in the database...but if it is a simple integer-like field, it probably doesn't matter and it can just be a part of the table record
	// TODO: How can we print a Money object without the freaking monetary symbol?  Work on it...
	// TODO: Also, there are several ways to format Money objects when they represent negative values...how to implement a MoneyFormat, or format(), or whatever?
	// TODO: Might just want to do a Format class just like Date so that it can take some basic parameters and then be 'the truth' about how Money objects get printed when they go thru the Formatter
	int amount;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * Creates an instance initialized with the supplied <code>int</code>
	 * amount.
	 * 
	 * @param amount The monetary amount kept in precise integer format.
	 */
	public Money(final int amount) {
		this.amount = amount;
	}

//	TODO: Move this functionality into a Formatter/Parser class
//	public Money(final String amount) {
//		final char[] ch = amount.toCharArray();
//		final boolean neg = (ch[0] == '-');
//		int d = -1;
//		int i = (neg) ? 1 : 0;
//
//		for (; i < ch.length; i++) {
//			if (ch[i] == '.') {
//				if (++d != 0)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//			} else {
//				if (d >= 0 && d++ == 2)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				if (ch[i] < '0' || ch[i] > '9')
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				this.amount = (this.amount << 3) + (this.amount << 1) + ch[i] - '0';
//			}
//		}
//
//		if (d <= 0)
//			this.amount *= 100;
//		else if (d == 1)
//			this.amount = (this.amount << 3) + (this.amount << 1);
//
//		if (neg)
//			this.amount = ~this.amount + 1;
//	}

	public Money(final Money... amounts) {
		for (Money m : amounts)
			amount += m.amount;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final int getAmount() {
		return amount;
	}

	public final void setAmount(final int amount) {
		this.amount = amount;
	}

	public final Money add(final Money m) {
		return new Money(amount + m.amount);
	}

	public void credit(final Money m) {
		amount += m.amount;
	}

//	public void credit(final String s) {
//		amount += new Money(s).amount;
//	}

	public void debit(final Money m) {
		amount -= m.amount;
	}

//	public void debit(final String s) {
//		amount -= new Money(s).amount;
//	}

	public Money divide(final int value) {
		final int q = amount / value;

		return new Money(((amount - (q * value)) << 1) >= value ? q + 1 : q);
	}

	public Percent divide(final Money divisor) {
		return new Percent(this, divisor);
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof Money)) {
			return false;
		}

		return ((Money) o).amount == amount;
	}

	@Override
	public int hashCode() {
		return amount;
	}

	public Money multiply(final int value) {
		return new Money(amount * value);
	}

	public Money multiply(final Percent p) {
		return p.multiply(this);
	}

	public Money subtract(final Money m) {
		return new Money(amount - m.amount);
	}

	public int compareTo(final Money m) {
		return (amount < m.amount) ? -1 : (amount == m.amount) ? 0 : 1;
	}

	public void extract(final Characters chars) {
		if (amount == Integer.MIN_VALUE) {
            chars.append('-','2','1','4','7','4','8','3','6','.','4','8');
            return;
		}

		int charsSize = chars.length();
		int charPos = stringSize(amount);
		final char[] buf = chars.getChars(charPos);
		final boolean sign = (amount < 0);
		charPos += charsSize;

		int s = (sign) ? -amount : amount;
		int q = s / 10;
		int r = s - (q << 3) - (q << 1);

		buf[--charPos] = Characters.digits[r];

		s = q;
		q = s / 10;
		r = s - (q << 3) - (q << 1);

		buf[--charPos] = Characters.digits[r];
		buf[--charPos] = '.';

		do {
			s = q;
			q = s / 10;
			r = s - (q << 3) - (q << 1);
			buf[--charPos] = Characters.digits[r];
		} while (q > 0);

		if (sign) {
			buf [--charPos] = '-';
		}
	}

	public final String toString() {
		final CharArrayBuilder chars = new CharArrayBuilder();
		extract(chars);
		return chars.toString();
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static int stringSize(final int i) {
		if (i < 0) {
			if (i > -10) return 5;
			if (i > -100) return 5;
			if (i > -1000) return 5;
			if (i > -10000) return 6;
			if (i > -100000) return 7;
			if (i > -1000000) return 8;
			if (i > -10000000) return 9;
			if (i > -100000000) return 10;
			if (i > -1000000000) return 11;

			return 12;
		}

		if (i < 10) return 4;
		if (i < 100) return 4;
		if (i < 1000) return 4;
		if (i < 10000) return 5;
		if (i < 100000) return 6;
		if (i < 1000000) return 7;
		if (i < 10000000) return 8;
		if (i < 100000000) return 9;
		if (i < 1000000000) return 10;

		return 11;
	}

	public static void main(String[] args) {
//		Money yo = new Money("3.49");

//		Money yo = new Money("-0.00");
//		Money yo = new Money("-21474836.48");
//		Money yo = new Money("-21474836.48");
//		Money yo = new Money("3.50");
//		yo.credit("7.19");
//		yo.debit("4.35");
//		yo.debit("6.24");
//		yo.debit("4993.75");

//		System.out.println(yo.multiply(27).divide(12));
//		System.out.println(yo);

		Money foo = new Money(1225000);
		Money bar = new Money(6000000);

		System.out.println(foo);
		System.out.println(bar);

		// ROI is actually 389.80% not 489.80%...guess we need a Finance object to work the magic
		System.out.println("ROI = " + bar.divide(foo));
		System.out.println("Ratio = " + foo.divide(bar));

		foo = new Money(747463);
		bar = new Money(639534);

		System.out.println("Ratio = " + bar.divide(foo));

		// 86113.04 * 85.56% = 73678.32
		foo = new Money(8611304);
		Percent p = new Percent("85.56");

		System.out.println("Amount = $" + foo.multiply(p));
	}

}
