package root.finance;

import root.data.validation.InvalidFormatException;
import root.lang.CharArrayBuilder;
import root.lang.Characters;
import root.lang.Extractable;

/**
 * Percent - http://www.math.com/school/subject1/lessons/S1U1L7GL.html
 * 
 * The default precision can be two decimal places, but in the wild you will see up to five decimal places
 * 
 * @author esmith
 */
public class Percent implements Comparable<Percent>, Extractable {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = -1143944421702669682L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private int percent;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Percent(final String amount) {
		final char[] ch = amount.toCharArray();
		final boolean neg = (ch[0] == '-');
		int d = -1;
		int i = (neg) ? 1 : 0;

		for (; i < ch.length && ch[i] != '%'; i++) {
			if (ch[i] == '.') {
				if (++d != 0)
					throw new InvalidFormatException("Invalid percent value {P}", amount);
			} else {
				if (d >= 0 && d++ == 2)
					throw new InvalidFormatException("Invalid percent value {P}", amount);

				if (ch[i] < '0' || ch[i] > '9')
					throw new InvalidFormatException("Invalid percent value {P}", amount);

				this.percent = (this.percent << 3) + (this.percent << 1) + ch[i] - '0';
			}
		}

		if (d <= 0)
			this.percent *= 100;
		else if (d == 1)
			this.percent = (this.percent << 3) + (this.percent << 1);

		if (neg)
			this.percent = ~this.percent + 1;
	}

	public Percent(final Money dividend, final Money divisor) {
		if (divisor.amount != 0) {
			final long l = dividend.amount;
			final int i = (int) ((l * 100000) / divisor.amount);
	
			percent = i / 10;
			if ((i - (percent << 3) - (percent << 1)) >= 5)
				percent++;
		}
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public int getValue() {
		return percent;
	}

	public int compareTo(final Percent p) {
		return (percent < p.percent) ? -1 : (percent == p.percent) ? 0 : 1;
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof Percent)) {
			return false;
		}

		return ((Percent) o).percent == percent;
	}

	@Override
	public int hashCode() {
		return percent;
	}

	public Money multiply(final Money m) {
		long l = m.amount;
		l = (l * percent) / 1000;
		final int r = (int) (l / 10);

		return new Money((l - (r << 3) - (r << 1)) < 5 ? r : r + 1);
	}

	public void extract(final Characters chars) {
		if (percent == Integer.MIN_VALUE) {
			chars.append('-','2','1','4','7','4','8','3','6','.','4','8','%');
			return;
		}

		int charsSize = chars.length();
		int charPos = stringSize(percent);
		final char[] buf = chars.getChars(charPos);
		final boolean sign = (percent < 0);
		charPos += charsSize;

		int s = (sign) ? -percent : percent;
		int q = s / 10;
		int r = s - (q << 3) - (q << 1);

		buf[--charPos] = '%';
		buf[--charPos] = Characters.digits[r];

		s = q;
		q = s / 10;
		r = s - (q << 3) - (q << 1);

		buf[--charPos] = Characters.digits[r];
		buf[--charPos] = '.';

		do {
			s = q;
			q = s / 10;
			r = s - (q << 3) - (q << 1);
			buf[--charPos] = Characters.digits[r];
		} while (q > 0);

		if (sign) {
			buf [--charPos] = '-';
		}
	}

	@Override
	public final String toString() {
		final CharArrayBuilder chars = new CharArrayBuilder();
		extract(chars);
		return chars.toString();
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static int stringSize(final int i) {
		if (i < 0) {
			if (i > -1000) return 6;
			if (i > -10000) return 7;
			if (i > -100000) return 8;
			if (i > -1000000) return 9;
			if (i > -10000000) return 10;
			if (i > -100000000) return 11;
			if (i > -1000000000) return 12;

			return 13;
		}

		if (i < 1000) return 5;
		if (i < 10000) return 6;
		if (i < 100000) return 7;
		if (i < 1000000) return 8;
		if (i < 10000000) return 9;
		if (i < 100000000) return 10;
		if (i < 1000000000) return 11;

		return 12;
	}

}
