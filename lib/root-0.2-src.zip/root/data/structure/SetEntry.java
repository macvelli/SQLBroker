package root.data.structure;

class SetEntry<K> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 8847867060549351982L;

	// <><><><><><><><><><><><> Class Attributes <><><><><><><><><><><><><><><>

	final K key;
	final int hash;
	SetEntry<K> next;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	SetEntry(final K key, final int h, final SetEntry<K> next) {
		this.key = key;
		this.hash = h;
		this.next = next;
	}

}
