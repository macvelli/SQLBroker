package root.data.structure;

import java.util.Collection;
import java.util.Iterator;

import root.lang.Itemizer;
import root.util.Safe;

/**
 * TODO:
 * 		+ See about pulling a MapImmutable out of a MapHashed, though MapHashed is going
 * 		  to need to implement Cloneable in order for it to work properly
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public class MapImmutable<K, V> implements Map<K, V> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = -107460966754469476L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final MapHashed<K, V> map;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	MapImmutable(final MapHashed<K, V> map) {
		this.map = map;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public void clear() {
		// TODO DELETE
	}

	@Override
	public final boolean equals(final Object o)  {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof MapImmutable)) {
			return false;
		}

		MapImmutable<?, ?> m = (MapImmutable<?, ?>) o;
		if (m.map.size != map.size) {
			return false;
		}

		Iterator<MapEntry<K, V>> i = map.iterator();
objs:	for (MapEntry<?, ?> e : m) {
			MapEntry<K, V> f = i.next();

			if (Safe.equals(e.key, f.key) && Safe.equals(e.value, f.value)) {
				continue objs;
			}

			return false;
		}

        return true;
	}

	@Override
	public final Collection<MapEntry<K, V>> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public Itemizer<MapEntry<K, V>> getDescending() {
		return new UnmodifiableItemizer<>(map.getDescending());
	}

	@Override
	public final int getSize() {
		return map.size;
	}

	@Override
	public final int hashCode() {
		return map.hashCode();
	}

	@Override
	public final boolean isEmpty() {
		return map.isEmpty();
	}

	@Override
	public final Itemizer<MapEntry<K, V>> iterator() {
		return new UnmodifiableItemizer<>(map.iterator());
	}

	public final boolean containsKey(final K key) {
		return map.containsKey(key);
	}

	public final boolean containsValue(final V value) {
		return map.containsValue(value);
	}

	public final V get(final K key) {
		return map.get(key);
	}

	@Override
	public V get(K key, V defaultVal) {
		// TODO DELETE
		return null;
	}

	@Override
	public V get(K key, Class<V> clazz) {
		// TODO DELETE
		return null;
	}

	@Override
	public V put(K key, V value) {
		// TODO DELETE
		return null;
	}

	@Override
	public V remove(K key) {
		// TODO DELETE
		return null;
	}

	@Override
	public final String toString() {
		return map.toString();
	}

}
