package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.memory.GenericPageTable;
import root.util.Random;
import root.util.Safe;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc (done)
 * 		+ Remove @Override annotations
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 *  
 * @author esmith
 *
 * @param <T>
 */
public class ListPageTable<T> implements List<T> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 2109606997336664119L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private int	size;
	private final GenericPageTable<T> pageTable;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListPageTable() {
		pageTable = new GenericPageTable<>();
	}

	public ListPageTable(final int numPages) {
		pageTable = new GenericPageTable<>(numPages);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void add(final T o) {
		pageTable.put(size, o);
		size++;
	}

	@Override
	@SafeVarargs
	public final void addAll(final T... a) {
		pageTable.putAll(size, a);
		size += a.length;
	}

	@Override
	public final void addAll(final Itemizable<? extends T> c) {
		pageTable.putAll(size, c);
		size += c.getSize();
	}

	@Override
	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	@Override
	public void clear() {
		pageTable.clear();
		size = 0;
	}

	@Override
	public final boolean contains(final T o) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(pageTable.get(i), o)) {
				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... a) {
		int i;
items:	for (T t : a) {
			for (i=0; i < size; i++) {
				if (Safe.equals(pageTable.get(i), t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Iterable<? extends T> c) {
		int i;
items:	for (T t : c) {
			for (i=0; i < size; i++) {
				if (Safe.equals(pageTable.get(i), t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... a) {
		int i;
		for (T t : a) {
			for (i=0; i < size; i++) {
				if (Safe.equals(pageTable.get(i), t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		for (T t : c) {
			for (int i=0; i < size; i++) {
				if (Safe.equals(pageTable.get(i), t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final T echo(final T o) {
		pageTable.put(size, o);
		size++;

		return o;
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof Iterable)) {
			return false;
		}

		final Iterable<?> i = (Iterable<?>) o;

		int j = 0;
		for (Object t : i) {
			if (j == size) {
				return false;
			}

			if (Safe.notEqual(pageTable.get(j), t)) {
				return false;
			}
		}

		return j == size;
	}

	@Override
	public final T get(final int i) {
		return pageTable.get(i);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Descend();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (int i=0; i < size; i++) {
			T t = pageTable.get(i);
			if (t != null) {
				h ^= t.hashCode();
			}
			h <<= 1;
		}

		return h;
	}

	@Override
	public final int indexOf(final T o) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(pageTable.get(i), o)) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public final void insert(final int i, final T o) {
		// TODO: DELETE
	}

	@Override
	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		// TODO: DELETE
	}

	@Override
	public final void insertAll(int i, final Itemizable<? extends T> c) {
		// TODO: DELETE
	}

	@Override
	public final void insertAll(final int i, final Iterable<? extends T> c) {
		// TODO: DELETE
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	@Override
	public final String join(final String sep) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final T last() {
		return (size > 0) ? pageTable.get(size - 1) : null;
	}

	@Override
	public final T random() {
		return pageTable.get(Random.nextIndex(size));
	}

	@Override
	public final T remove(final int i) {
		// TODO: DELETE
		return null;
	}

	@Override
	public final boolean remove(final T o) {
		// TODO: DELETE
		return false;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final T... a) {
		// TODO: DELETE
		return false;
	}

	@Override
	public final boolean removeAll(final Iterable<? extends T> c) {
		// TODO: DELETE
		return false;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(pageTable.get(i), o)) {
				pageTable.put(i, n);
				return true;
			}
		}

		return false;
	}

	@Override
	public final void set(final int i, final T t) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		pageTable.put(i, t);
	}

	@Override
	public final void shuffle() {
		for (int i=0; i < size; i++) {
			final int j = Random.nextIndex(size);
			final T t = pageTable.get(i);
			pageTable.put(i, pageTable.get(j));
			pageTable.put(j, t);
		}
	}

	@Override
	public final ListArray<T> subList(final int from) {
		return subList(from, size);
	}

	@Override
	public final ListArray<T> subList(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final int len = to - from;
		final ListArray<T> a = new ListArray<T>(len);

		pageTable.arraycopy(from, a.values, 0, len);
		a.size = len;

		return a;
	}

	@Override
	public final SetHashed<T> subset(final int from) {
		return subset(from, size);
	}

	@Override
	public final SetHashed<T> subset(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final SetHashed<T> s = new SetHashed<T>(to-from);

		for (int i=from; i < to; i++) {
			s.add(pageTable.get(i));
		}

		return s;
	}

	@Override
	@SafeVarargs
	@SuppressWarnings("unchecked")
	public final T[] toArray(T... a) {
		a = (a.length == size) ? a : (T[]) new Object[size];

		pageTable.arraycopy(0, a, 0, size);

		return a;
	}

	public final SetHashed<T> toSet() {
		return subset(0, size);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		for (int i=0; i < size; i++) {
			builder.separator(1).append(pageTable.get(i));
		}
		builder.append(']');

		return builder.toString();
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	private class Ascend implements Itemizer<T> {

		private int i;

		@Override
		public final boolean hasNext() {
			return i < size;
		}

		@Override
		public final T next() {
			if (i >= size) {
				throw new NoSuchElementException();
			}

			return pageTable.get(i++);
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final int getIndex() {
			return i-1;
		}

		public final void reset() {
			i = 0;
		}

	}	// End Ascend

	private class Descend implements Itemizer<T> {

		private int i = size;

		@Override
		public final boolean hasNext() {
			return i > 0;
		}

		@Override
		public final T next() {
			if (i == 0) {
				throw new NoSuchElementException();
			}

			return pageTable.get(--i);
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final int getIndex() {
			return i;
		}

		@Override
		public final void reset() {
			i = size;
		}

	}	// End Descend

}
