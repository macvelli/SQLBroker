package root.data.structure;

import root.lang.Itemizer;

public interface Collector<E> extends Iterable<E> {

	public void add(E e);

	public Itemizer<E> iterator();

	public E[] toArray();

}	// End Collector
