package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Fast;
import root.util.Safe;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public class SetMultiKey<T> implements Set<T[]> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 8131068743526181369L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private int size;
	private int	capacity;
	private SetEntry<T[]>[] table;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public SetMultiKey() {
		capacity = 8;
		table = newArray(11);
	}

	public SetMultiKey(final int capacity) {
		this.capacity = Fast.max(capacity, 8);
		table = newArray(this.capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final boolean add(final T[] e) {
		final int h = Safe.hashCode(e);
		int i = h % table.length;

		for (SetEntry<T[]> n = table[i]; n != null; n = n.next) {
			if (Safe.equals(n.key, e)) {
				return false;
			}
		}

		if (size++ == capacity) {
			i = resize(h);
		}

		table[i] = new SetEntry<T[]>(e, h, table[i]);

		return true;
	}

	@SafeVarargs
	public final void addAll(final T[]... a) {
		for (T[] t : a) {
			add(t);
		}
	}

	public final void addAll(final Iterable<? extends T[]> c) {
		for (T[] t : c) {
			add(t);
		}
	}

	@Override
	public final void clear() {
		SetEntry<T[]> next;

		for (int i=0; i < table.length; i++) {
			for (SetEntry<T[]> n = table[i]; n != null; n = next) {
				next = n.next;
				n.next = null;
			}
			table[i] = null;
		}

		size = 0;
	}

	public final boolean contains(final T[] e) {
		for (SetEntry<T[]> n = table[Safe.hashCode(e) % table.length]; n != null; n = n.next) {
			if (Safe.equals(n.key, e)) {
				return true;
			}
		}

		return false;
	}

	@SafeVarargs
	public final boolean containsAll(final T[]... a) {
		SetEntry<T[]> n;

items:	for (T[] t : a) {
			for (n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	public final boolean containsAll(final Iterable<? extends T[]> c) {
items:	for (T[] t : c) {
			for (SetEntry<T[]> n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@SafeVarargs
	public final boolean containsAny(final T[]... a) {
		for (T[] t : a) {
			for (SetEntry<T[]> n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					return true;
				}
			}
		}

		return false;
	}

	public final boolean containsAny(final Iterable<? extends T[]> c) {
		for (T[] t : c) {
			for (SetEntry<T[]> n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					return true;
				}
			}
		}

		return false;
	}

	public final SetMultiKey<T> difference(final Iterable<? extends T[]> c) {
		final SetMultiKey<T> set = new SetMultiKey<>(size);

		for (T[] t : c) {
			if (!this.contains(t)) {
				set.add(t);
			}
		}

		return set;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final boolean equals(final Object o) {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof SetMultiKey)) {
			return false;
		}

		final SetMultiKey<T> m = (SetMultiKey<T>) o;
		if (m.size != size) {
			return false;
		}

objs:	for (SetEntry<T[]> e : m.getSetEntryItemizer()) {
			for (SetEntry<T[]> f = table[e.hash % table.length]; f != null; f = f.next) {
				if (Safe.equals(e.key, f.key)) {
					continue objs;
				}
			}

			return false;
		}

        return true;
	}

	public final T[] get(final T[] e) {
		int i = Safe.hashCode(e) % table.length;

		for (SetEntry<T[]> n = table[i]; n != null; n = n.next) {
			if (Safe.equals(n.key, e)) {
				return n.key;
			}
		}

		return null;
	}

	@Override
	public final Collection<T[]> getCollection() {
		return new ItemizableDelegate<T[]>(this);
	}

	@Override
	public final Itemizer<T[]> getDescending() {
		return new StackArray<>(this).iterator();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (int i=0; i < table.length; i++) {
			for (SetEntry<T[]> e = table[i]; e != null; e = e.next) {
				h ^= e.hash;
				h <<= 1;
			}
		}

		return h;
	}

	public final SetMultiKey<T> intersect(final Iterable<? extends T[]> c) {
		final SetMultiKey<T> set = new SetMultiKey<>(size);

		for (T[] t : c) {
			if (this.contains(t)) {
				set.add(t);
			}
		}

		return set;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T[]> iterator() {
		return new Ascend();
	}

	public final boolean remove(final T[] o) {
		final int i = Safe.hashCode(o) % table.length;

		for (SetEntry<T[]> n = table[i], prev = null; n != null; prev = n, n = n.next) {
			if (Safe.equals(n.key, o)) {
				if (prev == null) {
					table[i] = n.next;
				} else {
					prev.next = n.next;
				}

				n.next = null;
				size--;
				return true;
			}
		}

		return false;
	}

	@SafeVarargs
	public final boolean removeAll(final T[]... a) {
		boolean itemRemoved = false;

		for (T[] t : a) {
			itemRemoved = remove(t) || itemRemoved;
		}

		return itemRemoved;
	}

	public final boolean removeAll(final Iterable<? extends T[]> c) {
		boolean itemRemoved = false;

		for (T[] t : c) {
			itemRemoved = remove(t) || itemRemoved;
		}

		return itemRemoved;
	}

	public final boolean replace(final T[] o, final T[] n) {
		return remove(o) && add(n);
	}

	@SafeVarargs
	public final T[][] toArray(T[]... t) {
		t = Fast.newInstance(t, size);

		for (int i=0, j=0; j < size; i++) {
			for (SetEntry<T[]> n = table[i]; n != null; n = n.next) {
				t[j++] = n.key;
			}
		}

		return t;
	}

	public ListArray<T[]> toList() {
		final ListArray<T[]> list = new ListArray<>(size);

		for (int i=0, j=0; j < size; i++) {
			for (SetEntry<T[]> n = table[i]; n != null; n = n.next) {
				list.values[j++] = n.key;
			}
		}

		return list;
	}

	public final SetMultiKey<T> union(final Iterable<? extends T[]> c) {
		final SetMultiKey<T> set = new SetMultiKey<>(size);

		set.addAll(this);
		set.addAll(c);

		return set;
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		if (size > 0) {
			for (int i=0; i < table.length; i++) {
				for (SetEntry<T[]> e = table[i]; e != null; e = e.next) {
					builder.separator(1).append(e.key);
				}
			}
		}
		builder.append(']');

		return builder.toString();
	}

	//  <><><><><><><><><><><><><>< Private Methods ><><><><><><><><><><><><><>

	private Itemizer<SetEntry<T[]>> getSetEntryItemizer() {
		return new SetEntryItemizer();
	}

	@SuppressWarnings("unchecked")
	private SetEntry<T[]>[] newArray(final int capacity) {
		return new SetEntry[Fast.hashTableSize(capacity)];
	}

	private int resize(final int h) {
		final SetEntry<T[]>[] oldTable = table;
		capacity = (capacity << 1) - (capacity >> 2);
		table = newArray(Fast.hashTableSize(capacity));

		SetEntry<T[]> next;
		for (int i=0, j=0; i < oldTable.length; i++) {
			for (SetEntry<T[]> n = oldTable[i]; n != null; n = next) {
				next = n.next;
				j = n.hash % table.length;
				n.next = table[j];
				table[j] = n;
			}
			oldTable[i] = null;
		}

		return h % table.length;
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	private final class Ascend implements Itemizer<T[]> {

		private int i, j;
		private SetEntry<T[]> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T[] next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = table[i++];
			}

			return e.key;
		}

		@Override
		public final void remove() {
			SetMultiKey.this.remove(e.key);
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final Itemizer<T[]> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}
		
	}	// End Ascend

	private final class SetEntryItemizer implements Itemizer<SetEntry<T[]>> {

		private int i, j;
		private SetEntry<T[]> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final SetEntry<T[]> next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = table[i++];
			}

			return e;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final Itemizer<SetEntry<T[]>> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}
		
	}	// End SetEntryItemizer

}
