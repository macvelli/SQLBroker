package root.data.structure;

import root.lang.Itemizable;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface Set<T> extends Itemizable<T> {

	boolean add(T e);

	void addAll(T... a);

	void addAll(Iterable<? extends T> c);

	boolean contains(T e);

	boolean containsAll(T... a);

	boolean containsAll(Iterable<? extends T> c);

	boolean containsAny(T... a);

	boolean containsAny(Iterable<? extends T> c);

	Set<T> difference(Iterable<? extends T> c);

	T get(T e);

	Set<T> intersect(Iterable<? extends T> c);

	boolean remove(T o);

	boolean removeAll(T... a);

	boolean removeAll(Iterable<? extends T> c);

	boolean replace(T o, T n);

	T[] toArray(T... e);

	List<T> toList();

	Set<T> union(Iterable<? extends T> c);

}
