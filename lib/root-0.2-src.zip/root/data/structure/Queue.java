package root.data.structure;

import root.lang.Itemizable;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface Queue<T> extends Itemizable<T> {

	T dequeue();

	void enqueue(T e);

	T peek();

}
