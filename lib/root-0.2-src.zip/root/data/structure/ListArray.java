package root.data.structure;

import java.util.ArrayList;

import root.lang.Itemizable;
import root.util.Random;
import root.util.Safe;

/**
 * Modern take on the classic {@link ArrayList}.
 * 
 * - An ArrayList is Serializable but its elementData array is marked as
 *   transient. This is possibly because the elementData array is of type
 *   Object[] which is not in of itself Serializable.
 *   	+ TODO: Test this theory by serializing a ListArray of Strings and see what happens
 * - An ArrayList now starts off with an empty elementData array and grows
 *   it when the first element is added. So a growth hit is taken for every
 *   single ArrayList that is actually used.
 * - An ArrayList has overflow and range checking whereas ListArray relies
 *   on <what does it rely on? figure this out and document>
 * - An ArrayList has a default capacity of 10 whereas a ListArray has a
 *   default capacity of 5.
 * - An ArrayList grows by 50% each time the size limit is reached whereas
 *   a ListArray grows by 100% each time its size limit is reached.
 *   	+ TODO: Put a table in here illustrating the difference
 * 
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc (done)
 * 		+ Remove @Override annotations
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Do we need something like from ArrayList:
 * 			o ensureCapacity(int)
 * 			o lastIndexOf(T t)
 * 			o What the hell does ListIterator give that Itemizer doesn't have?
 * 			o retainAll(Iterable)
 * 			o trimToSize(), which I would call compact()
 * 		+ What about having equals() be a catch-all and implement n number of
 * 		  isEqualTo() methods for specific Root implementations (whichever make
 * 		  sense for a given data structure)?
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 *  
 * @author esmith
 *
 * @param <T>
 */
public class ListArray<T> extends DynamicArray<T> implements List<T> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 2109606997336664119L;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	public ListArray() {
		super(5);
	}

	public ListArray(final int capacity) {
		super(capacity);
	}

	/**
	 * This constructor just passes the array created for the vararg at
	 * runtime into the super constructor for maximum performance.
	 * 
	 * @param a
	 */
	@SafeVarargs
	public ListArray(final T... a) {
		super(a);
	}

	public ListArray(final Iterable<? extends T> c) {
		super(5);

		for (T t : c) {
			add(t);
		}
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	@Override
	public final void add(final T o) {
		if (size == values.length) {
			resize(size << 1);
		}

		values[size++] = o;
	}

	/**
	 * TODO: Test boundary condition where newSize == values.length
	 */
	@Override
	@SafeVarargs
	public final void addAll(final T... a) {
		final int newSize = size + a.length;

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}

		System.arraycopy(a, 0, values, size, a.length);
		size = newSize;
	}

	/**
	 * TODO: Test boundary condition where newSize == values.length
	 */
	@Override
	public final void addAll(final Itemizable<? extends T> c) {
		final int newSize = size + c.getSize();

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}

		for (T t : c) {
			values[size++] = t;
		}
	}

	@Override
	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	@Override
	public final boolean contains(final T o) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(values[i], o)) {
				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... a) {
		int i;
items:	for (T t : a) {
			for (i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Iterable<? extends T> c) {
		int i;
items:	for (T t : c) {
			for (i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... a) {
		int i;
		for (T t : a) {
			for (i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		for (T t : c) {
			for (int i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final T echo(final T o) {
		if (size == values.length) {
			resize(size << 1);
		}

		values[size++] = o;

		return o;
	}

	@Override
	public final int indexOf(final T o) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(values[i], o)) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public final void insert(final int i, final T o) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		if (size == values.length) {
			resize(size << 1);
		}

		if (i < size++) {
			System.arraycopy(values, i, values, i+1, size-i);
		}

		values[i] = o;
	}

	/**
	 * TODO: Test boundary condition where newSize == values.length and i == size
	 */
	@Override
	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		final int newSize = size + a.length;

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}

		if (i < size) {
			System.arraycopy(values, i, values, i+a.length, size-i);
		}

		System.arraycopy(a, 0, values, i, a.length);
		size = newSize;
	}

	/**
	 * TODO: Test boundary condition where newSize == values.length and i == size
	 */
	@Override
	public final void insertAll(int i, final Itemizable<? extends T> c) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		final int newSize = size + c.getSize();

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}

		if (i < size) {
			System.arraycopy(values, i, values, i+c.getSize(), size-i);
		}

		for (T t : c) {
			values[i++] = t;
		}
	}

	@Override
	public final void insertAll(final int i, final Iterable<? extends T> c) {
		final ListArray<T> list = new ListArray<T>(c);

		insertAll(i, list);
	}

	@Override
	public final String join(final String sep) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final boolean remove(final T o) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(values[i], o)) {
				System.arraycopy(values, i+1, values, i, size-i);
				values[--size] = null;

				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		int i;
items:	for (T t : a) {
			for (i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					System.arraycopy(values, i+1, values, i, size-i);
					values[--size] = null;
					continue items;
				}
			}
		}

		return origSize != size;
	}

	@Override
	public final boolean removeAll(final Iterable<? extends T> c) {
		final int origSize = size;

		int i;
items:	for (T t : c) {
			for (i=0; i < size; i++) {
				if (Safe.equals(values[i], t)) {
					System.arraycopy(values, i+1, values, i, size-i);
					values[--size] = null;
					continue items;
				}
			}
		}

		return origSize != size;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		for (int i=0; i < size; i++) {
			if (Safe.equals(values[i], o)) {
				values[i] = n;
				return true;
			}
		}

		return false;
	}

	@Override
	public final void set(final int i, final T t) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		values[i] = t;
	}

	/**
	 * TODO: Rethink the Random.nextIndex() stuff and make sure it's kosher with massive #'s of instances doing it concurrently
	 */
	@Override
	public final void shuffle() {
		int j;
		T z;

		for (int i = size; i > 1;) {
			j = Random.nextIndex(i--);
			z = values[j];
			values[j] = values[i];
			values[i] = z;
		}
	}

	@Override
	public final ListArray<T> subList(final int from) {
		return subList(from, size);
	}

	@Override
	public final ListArray<T> subList(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final int len = to - from;
		final ListArray<T> a = new ListArray<T>(len);

		System.arraycopy(values, from, a.values, 0, len);
		a.size = len;

		return a;
	}

	@Override
	public final SetHashed<T> subset(final int from) {
		return subset(from, size);
	}

	@Override
	public final SetHashed<T> subset(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final SetHashed<T> s = new SetHashed<T>(to-from);

		for (int i=from; i < to; i++) {
			s.add(values[i]);
		}

		return s;
	}

	public final SetHashed<T> toSet() {
		return subset(0, size);
	}

}
