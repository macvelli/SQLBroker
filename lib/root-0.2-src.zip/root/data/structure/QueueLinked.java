package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Remove @Override annotations from Queue<T> methods (done)
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 * 		+ Check http://math.hws.edu/eck/cs124/javanotes3/c11/s3.html out for some ideas
 * 
 * @author esmith
 *
 * @param <T>
 */
public class QueueLinked<T> implements Queue<T> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = -6709308169199675487L;

	// <><><><><><><><><><><><> Class Attributes <><><><><><><><><><><><><><><>

	private int		size;
	private Node<T> head;
	private Node<T>	tail;

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		Node.clear(head);

		head = null;
		tail = null;
		size = 0;
	}

	public final T dequeue() {
		if (size == 0) {
			throw new NoSuchElementException();
		}

		final Node<T> n = head;
		head = head.next;

		if (head == null) {
			tail = null;
		}

		final T t = n.data;
		n.data = null;
		n.next = null;
		size--;

		return t;
	}

	public final void enqueue(final T t) {
		final Node<T> node = new Node<T>(t);

		if (tail == null) {
			head = node;
		} else {
			tail.next = node;
		}

		tail = node;
		size++;
	}

	@Override
	public final boolean equals(final Object o) {
		return Node.equals(o, head);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Node.Descend<>(head, size);
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		return Node.hashCode(head, size);
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Node.Ascend<T>(head);
	}

	public final T peek() {
		return (head == null) ? null : head.data;
	}

	@Override
	public final String toString() {
		return Node.toString(head, size);
	}

}
