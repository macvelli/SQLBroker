package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;

final class ItemizableDelegate<T> implements Collection<T> {

	private final Itemizable<T> i;

	ItemizableDelegate(final Itemizable<T> i) {
		this.i = i;
	}

	public boolean add(T o) {
		throw new UnsupportedOperationException();
	}

	public boolean addAll(Collection<? extends T> c) {
		throw new UnsupportedOperationException();
	}

	public void clear() {
		i.clear();
	}

	public boolean contains(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean containsAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}

	public boolean isEmpty() {
		return i.isEmpty();
	}

	public Itemizer<T> iterator() {
		return i.iterator();
	}

	public boolean remove(Object o) {
		throw new UnsupportedOperationException();
	}

	public boolean removeAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}

	public boolean retainAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}

	public int size() {
		return i.getSize();
	}

	public Object[] toArray() {
		throw new UnsupportedOperationException();
	}

	public <E> E[] toArray(E[] a) {
		throw new UnsupportedOperationException();
	}

}
