package root.data.structure;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import root.lang.Characters;
import root.lang.Itemizable;
import root.lang.Itemizer;
import root.util.Fast;
import root.util.Random;
import root.util.Safe;

/**
 * TODO
 * 		+ First, this thing won't work once I take List<T> away from all the list
 * 		  implementations
 * 		+ Second, this thing is fucked up
 * 		+ Third, what can I do for a sub-list view?
 * 
 * @author esmith
 *
 * @param <T>
 */
class SubList<T> implements List<T> {

	private static final long serialVersionUID = -7568837972118704233L;

	private int size;
	private final int offset;
	private final List<T> l;

	SubList(List<T> list, int fromIndex, int toIndex) {
		if (fromIndex < 0)
			throw new IllegalArgumentException("fromIndex = " + fromIndex);
		if (toIndex > list.getSize())
			throw new IndexOutOfBoundsException(toIndex, list.getSize());
		if (fromIndex > toIndex)
			throw new IllegalArgumentException("fromIndex(" + fromIndex + ") > toIndex(" + toIndex + ")");

        l = list;
        offset = fromIndex;
        size = toIndex - fromIndex;
    }

	public void add(T e) {
		l.insert(size+offset, e);
		size++;
	}

	public void addAll(T... a) {
        l.insertAll(size+offset, a);
        size += a.length;
	}

	public void addAll(Iterable<? extends T> c) {
		for (T t : c) {
			l.insert(size+offset, t);
			size++;
		}
	}

	public void clear() {
		for (int i=0; i < size; i++) {
			l.remove(offset);
		}

		size = 0;
	}

	public boolean contains(T e) {
		int i = l.indexOf(e);

		return i >= offset && i < size+offset;
	}

	public boolean containsAll(T... a) {
		boolean b = true;

		for (int i=0; i < a.length && b; i++) {
			b = contains(a[i]);
		}

		return b;
	}

	public boolean containsAll(Iterable<? extends T> c) {
		boolean b = true;

		for (Iterator<? extends T> i = c.iterator(); i.hasNext() && b;) {
			b = contains(i.next());
		}

		return b;
	}

	public boolean containsAny(T... a) {
		boolean b = false;

		for (int i=0; i < a.length && !b; i++) {
			b = contains(a[i]);
		}

		return b;
	}

	public boolean containsAny(Iterable<? extends T> c) {
		boolean b = false;

		for (Iterator<? extends T> i = c.iterator(); i.hasNext() && !b;) {
			b = contains(i.next());
		}

		return b;
	}

	public Itemizer<T> descending() {
		return new Dec();
	}

	public T echo(T e) {
		l.insert(size+offset, e);
		size++;
		return e;
	}

	public T get(int i) {
		if (i >= size || i < 0)
			throw new IndexOutOfBoundsException(i, size);

        return l.get(i+offset);
	}

	public Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	public int getSize() {
		return size;
	}

	public int indexOf(T e) {
		int i = l.indexOf(e) - offset;

		return (i < 0 || i >= size) ? -1 : i;
	}

	public void insert(int i, T e) {
		if (i > size || i < 0)
			throw new IndexOutOfBoundsException(i, size);

		l.insert(i+offset, e);
		size++;
	}

	public void insertAll(int i, T... a) {
		for (T t : a) {
			insert(i++, t);
		}
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public Itemizer<T> iterator() {
		return new Inc();
	}

	// TODO: Why is there this version, an Array.join() version, and a Safe.toString() version? 
	public String join(String sep) {
		if (size == 0)
			return "[]";

		Object o;
		int strLen = 2;
		int end = size+offset;
		final String[] strs = new String[size];
		for (int i=offset; i < end; i++) {
			o = l.get(i);
			strs[i] = (o == null) ? Safe.NULL : o.toString();
			strLen += strs[i].length();
		}

		final int sepLen = sep.length();
		final char[] c = new char[strLen + ((size - 1) * sepLen)];
		strLen = strs[0].length();

		c[0] = '[';
		strs[0].getChars(0, strLen, c, 1);
		int j = strLen + 1;
		for (int i=1; i < size; i++) {
			sep.getChars(0, sepLen, c, j);
			j += sepLen;
			strLen = strs[i].length();
			strs[i].getChars(0, strLen, c, j);
			j += strLen;
		}
		c[j] = ']';

		return new String(c);
	}

	public T last() {
		return l.get(size+offset);
	}

	public T random() {
        return l.get(Random.nextIndex(size)+offset);
	}

	public T remove(int i) {
		if (i > size || i < 0)
			throw new IndexOutOfBoundsException(i, size);

		T t = l.remove(i+offset);
		size--;

		return t;
	}

	public boolean remove(T e) {
		int i = indexOf(e);

		if (i >= 0) {
			l.remove(i+offset);
			size--;
			return true;
		}

		return false;
	}

	public boolean removeAll(T... a) {
		boolean b = false;

		for (T t : a) {
			b = b || remove(t);
		}

		return b;
	}

	public boolean removeAll(Iterable<? extends T> c) {
		boolean b = false;

		for (T t : c) {
			b = b || remove(t);
		}

		return b;
	}

	public boolean replace(T o, T n) {
		int i = indexOf(o);

		if (i >= 0) {
			return l.replace(o, n);
		}

		return false;
	}

	public void set(int i, T e) {
		if (i >= size || i < 0)
			throw new IndexOutOfBoundsException(i, size);

		l.set(i+offset, e);
	}

	public void shuffle() {
		int i=0, j;
		T z;

		// 1. Create an array of T elements to make this easier to implement
		final T[] elements = (T[]) new Object[size];
		for (j = offset; i < size; i++) {
			elements[i] = l.get(j++);
		}

		// 2. Shuffle the element array
		for (i = size; i > 1;) {
			j = Random.nextIndex(i--);
			z = elements[j];
			elements[j] = elements[i];
			elements[i] = z;
		}

		// 3. Reorder the underlying list
		for (i=0, j=offset; i < size; i++) {
			l.set(j++, elements[i]);
		}
	}

	public List<T> subList(int from) {
		return l.subList(from+offset, size+offset);
	}

	public List<T> subList(int from, int to) {
		return l.subList(from+offset, to+offset);
	}

	public SubList<T> subListView(int from) {
		return new SubList<T>(this.l, from+offset, size);
	}

	public SubList<T> subListView(int from, int to) {
		return new SubList<T>(this.l, from+offset, to+offset);
	}

	public Set<T> subset(int from) {
		return subset(from, size);
	}

	public Set<T> subset(int from, int to) {
		if (from >= to || from < 0)
			throw new IndexOutOfBoundsException(from, to);

		if (to > size)
			throw new IndexOutOfBoundsException(to, size);

		Set<T> s = new SetHashed<T>(to-from);

		for (int i=from; i < to; i++) {
			s.add(l.get(i+offset));
		}

		return s;
	}

	
	public T[] toArray(T... a) {
		a = Fast.newInstance(a, size);

		for (int i=0; i < size; i++) {
			a[i] = l.get(i+offset);
		}

		return a;
	}

	public Set<T> toSet() {
		return subset(0, size);
	}

	public void extract(Characters chars, boolean enclosed) {
		// TODO Auto-generated method stub
		
	}

	public void extract(final Characters chars) {
		// TODO Auto-generated method stub
		
	}

	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Classes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private class Inc implements Itemizer<T> {

		private int i = offset;
		private int end = size+offset;

		public boolean hasNext() {
			return i < end;
		}

		public T next() {
			if (i == end)
				throw new NoSuchElementException();

			return l.get(i);
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public int getIndex() {
			// TODO Auto-generated method stub
			return 0;
		}

		public Itemizer<T> iterator() {
			return this;
		}

		public void reset() {
			// TODO Auto-generated method stub
			
		}

	}	// End Inc

	private class Dec implements Itemizer<T> {

		private int i = size+offset;

		public boolean hasNext() {
			return i > offset;
		}

		public Itemizer<T> iterator() {
			return this;
		}

		public T next() {
			if (i == offset)
				throw new NoSuchElementException();

			return l.get(--i);
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public int getIndex() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public void reset() {
			// TODO Auto-generated method stub
			
		}

	}	// End Dec

	@Override
	public void insertAll(int i, Iterable<? extends T> c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Itemizer<T> getDescending() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addAll(Itemizable<? extends T> c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertAll(int i, Itemizable<? extends T> c) {
		// TODO Auto-generated method stub
		
	}

}	// End SubList
