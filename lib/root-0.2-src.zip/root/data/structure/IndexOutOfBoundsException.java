package root.data.structure;

import root.lang.ParamStr;

public class IndexOutOfBoundsException extends RuntimeException {

	private static final long serialVersionUID = 8930543884997274522L;

	public IndexOutOfBoundsException(final int index, final int size) {
		super(ParamStr.format("Index: {P}, Size: {P}", index, size));
	}

}	// End IndexOutOfBoundsException
