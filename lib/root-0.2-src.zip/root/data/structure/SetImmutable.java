package root.data.structure;

import java.util.Collection;

import root.lang.Itemizer;
import root.util.Safe;

/**
 * TODO:
 * 		+ See about pulling a SetImmutable out of a SetHashed, though SetHashed is going
 * 		  to need to implement Cloneable in order for it to work properly
 * 
 * @author esmith
 *
 * @param <T>
 */
public class SetImmutable<T> implements Set<T> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 6811826269454552413L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final SetHashed<T> set;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	SetImmutable(final SetHashed<T> set) {
		this.set = set;
	}

	@SafeVarargs
	public SetImmutable(final T... a) {
		set = new SetHashed<>(a.length);
		set.addAll(a);
	}

	public SetImmutable(final Iterable<? extends T> c) {
		set = new SetHashed<>();
		set.addAll(c);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public void clear() {
		// TODO DELETE
	}

	@Override
	public boolean add(T e) {
		// TODO DELETE
		return false;
	}

	@Override
	public void addAll(T... a) {
		// TODO DELETE
		
	}

	@Override
	public void addAll(Iterable<? extends T> c) {
		// TODO DELETE
		
	}

	public final boolean contains(final T e) {
		return set.contains(e);
	}

	@SafeVarargs
	public final boolean containsAll(final T... a) {
		return set.containsAll(a);
	}

	public final boolean containsAll(final Iterable<? extends T> c) {
		return set.containsAll(c);
	}

	@SafeVarargs
	public final boolean containsAny(final T... a) {
		return set.containsAny(a);
	}

	public final boolean containsAny(final Iterable<? extends T> c) {
		return set.containsAny(c);
	}

	public final SetHashed<T> difference(final Iterable<? extends T> c) {
		return set.difference(c);
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof SetImmutable)) {
			return false;
		}

		final SetImmutable<?> s = (SetImmutable<?>) o;
		if (s.set.size != set.size) {
			return false;
		}

objs:	for (SetEntry<?> e : s.set.getSetEntryItemizer()) {
			for (SetEntry<T> n = set.table[e.hash % set.table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, e.key)) {
					continue objs;
				}
			}

			return false;
		}

		return true;
	}

	public final T get(final T e) {
		return set.get(e);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new UnmodifiableItemizer<>(set.getDescending());
	}

	@Override
	public final int getSize() {
		return set.size;
	}

	@Override
	public final int hashCode() {
		return set.hashCode();
	}

	public final SetHashed<T> intersect(final Iterable<? extends T> c) {
		return set.intersect(c);
	}

	@Override
	public final boolean isEmpty() {
		return set.isEmpty();
	}

	@Override
	public final Itemizer<T> iterator() {
		return new UnmodifiableItemizer<>(set.iterator());
	}

	@Override
	public boolean remove(T o) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean removeAll(T... a) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean removeAll(Iterable<? extends T> c) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean replace(T o, T n) {
		// TODO DELETE
		return false;
	}

	@SafeVarargs
	public final T[] toArray(final T... e) {
		return set.toArray(e);
	}

	public final ListArray<T> toList() {
		return set.toList();
	}

	public final SetHashed<T> union(final Iterable<? extends T> c) {
		return set.union(c);
	}

	@Override
	public final String toString() {
		return set.toString();
	}

}
