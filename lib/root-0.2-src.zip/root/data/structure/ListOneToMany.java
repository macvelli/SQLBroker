package root.data.structure;

import java.util.Collection;

import root.lang.Affiliate;
import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;

/**
 * Only useful for situations where you have domain objects auto-generated
 * with a default constructor yet you still want to wire the class on the 
 * 1-side of the relationship to the affiliate class on the N-side.
 * 
 * TODO
 * 		+ Implement equals() and hashCode() motherfucker
 * 
 * @author esmith
 *
 * @param <O>
 * @param <M>
 */
public class ListOneToMany<O, M extends Affiliate<O>> implements List<M> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 8131098011263556047L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final O one;
	private final ListArray<M> list;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListOneToMany(final O one) {
		this.one = one;
		this.list = new ListArray<>();
	}

	public ListOneToMany(final O one, final int capacity) {
		this.one = one;
		this.list = new ListArray<>(capacity);
	}

	private ListOneToMany(final O one, final ListArray<M> list) {
		this.one = one;
		this.list = list;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void add(final M m) {
		m.associate(one);
		list.add(m);
	}

	@SafeVarargs
	public final void addAll(final M... a) {
		for (M m : a) {
			m.associate(one);
		}

		list.addAll(a);
	}

	public final void addAll(final Itemizable<? extends M> c) {
		for (M m : c) {
			m.associate(one);
		}

		list.addAll(c);
	}

	/**
	 * This is a prime example of why it is good to know how your data
	 * structures operate.  There is no benefit to call list.addAll()
	 * in this situation so we just go ahead and call list.add() when
	 * processing M objects.
	 */
	public final void addAll(final Iterable<? extends M> c) {
		for (M m : c) {
			m.associate(one);
			list.add(m);
		}
	}

	@Override
	public final void clear() {
		list.clear();
	}

	public final boolean contains(final M m) {
		return list.contains(m);
	}

	@SafeVarargs
	public final boolean containsAll(final M... a) {
		return list.containsAll(a);
	}

	public final boolean containsAll(final Iterable<? extends M> c) {
		return list.containsAll(c);
	}

	@SafeVarargs
	public final boolean containsAny(final M... a) {
		return list.containsAny(a);
	}

	public final boolean containsAny(final Iterable<? extends M> c) {
		return list.containsAny(c);
	}

	public final M echo(final M m) {
		m.associate(one);
		return list.echo(m);
	}

	@Override
	public final boolean equals(final Object o) {
		throw new UnsupportedOperationException();
	}

	public final M get(final int i) {
		return list.get(i);
	}

	@Override
	public final Collection<M> getCollection() {
		return list.getCollection();
	}

	@Override
	public final Itemizer<M> getDescending() {
		return list.getDescending();
	}

	@Override
	public final int getSize() {
		return list.getSize();
	}

	@Override
	public final int hashCode() {
		throw new UnsupportedOperationException();
	}

	public final int indexOf(final M m) {
		return list.indexOf(m);
	}

	public final void insert(final int i, final M m) {
		list.insert(i, m);
		m.associate(one);
	}

	@SafeVarargs
	public final void insertAll(final int i, final M... a) {
		list.insertAll(i, a);
		for (M m : a) {
			m.associate(one);
		}
	}

	public final void insertAll(final int i, final Itemizable<? extends M> c) {
		list.insertAll(i, c);
		for (M m : c) {
			m.associate(one);
		}
	}

	public final void insertAll(final int i, final Iterable<? extends M> c) {
		list.insertAll(i, c);
		for (M m : c) {
			m.associate(one);
		}
	}

	@Override
	public final boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public final Itemizer<M> iterator() {
		return list.iterator();
	}

	public final String join(final String sep) {
		return list.join(sep);
	}

	public final M last() {
		return list.last();
	}

	public final M random() {
		return list.random();
	}

	public final M remove(final int i) {
		return list.remove(i);
	}

	public final boolean remove(final M m) {
		return list.remove(m);
	}

	@SafeVarargs
	public final boolean removeAll(final M... a) {
		return list.removeAll(a);
	}

	public final boolean removeAll(final Iterable<? extends M> c) {
		return list.removeAll(c);
	}

	public final boolean replace(final M o, final M n) {
		final boolean success = list.replace(o, n);

		if (success) {
			n.associate(one);
		}

		return success;
	}

	public final void set(final int i, final M m) {
		list.set(i, m);
		m.associate(one);
	}

	public final void shuffle() {
		list.shuffle();
	}

	public final ListOneToMany<O, M> subList(final int from) {
		return new ListOneToMany<O, M>(one, list.subList(from));
	}

	public final ListOneToMany<O, M> subList(final int from, final int to) {
		return new ListOneToMany<O, M>(one, list.subList(from, to));
	}

	public final SetHashed<M> subset(final int from) {
		return list.subset(from);
	}

	public final SetHashed<M> subset(final int from, final int to) {
		return list.subset(from, to);
	}

	@SafeVarargs
	public final M[] toArray(final M... a) {
		return list.toArray(a);
	}

	public final SetHashed<M> toSet() {
		return list.subset(0, list.size);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(list.size << 4);

		builder.append(one).append('\n');
		builder.append('[');
		final int start = builder.length();
		for (int i=0; i < list.size; i++) {
			builder.separator(start).append(list.values[i]);
		}
		builder.append(']');

		return builder.toString();
	}

}
