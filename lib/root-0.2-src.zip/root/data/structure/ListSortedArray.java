package root.data.structure;

import java.util.Arrays;

import root.lang.Itemizable;

/**
 * Similar to the {@link ListArray} though it keeps its elements in sorted
 * order.
 * 
 * TODO:
 * 		+ Add final designation to every non-private method
 * 		+ Add final designation to every method argument that is not used as a local variable
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc
 * 		+ Remove @Override annotations
 * 		+ Finish implementing List methods that are down at the bottom
 * 		+ Set this up like the Immutables where unsupported operations will be deleted once the List<T> implements is removed
 * 
 * @author esmith
 *
 * @param <T>
 */
public class ListSortedArray<T extends Comparable<? super T>> extends DynamicArray<T> implements List<T> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 7103504993659021281L;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	public ListSortedArray() {
		super(5);
	}

	/**
	 * This constructor passes the array created for the vararg at runtime
	 * into the super constructor for maximum performance. Then the value
	 * array is sorted to finish initialization.
	 * 
	 * @param a
	 */
	@SafeVarargs
	public ListSortedArray(final T... a) {
		super(a);
		Arrays.sort(values);
	}

	public ListSortedArray(final int capacity) {
		super(capacity);
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	public final void add(final T o) {
		if (size == values.length) {
			resize(size << 1);
		}

		int i = indexOf(o);
		if (i < 0) {
			i = ~i;
		}

		if (i < size) {
			System.arraycopy(values, i, values, i+1, size-i);
		}
		size++;

		values[i] = o;
	}

	@SafeVarargs
	public final void addAll(final T... a) {
		final int newSize = size + a.length;

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}

		System.arraycopy(a, 0, values, size, a.length);
		size = newSize;
		Arrays.sort(values);
	}

	public final void addAll(final Itemizable<? extends T> c) {
		final int newSize = size + c.getSize();

		if (newSize > values.length) {
			resize(newSize + (newSize >> 2));
		}
		
		for (T t : c) {
			values[size++] = t;
		}
		Arrays.sort(values);
	}

	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	public final boolean contains(final T o) {
		return indexOf(o) >= 0;
	}

	@SafeVarargs
	public final boolean containsAll(final T... a) {
		for (T t : a) {
			if (indexOf(t) < 0) {
				return false;
			}
		}

		return true;
	}

	public final boolean containsAll(final Iterable<? extends T> c) {
		for (T t : c) {
			if (indexOf(t) < 0) {
				return false;
			}
		}

		return true;
	}

	@SafeVarargs
	public final boolean containsAny(final T... a) {
		for (T t : a) {
			if (indexOf(t) >= 0) {
				return true;
			}
		}

		return false;
	}

	public final boolean containsAny(final Iterable<? extends T> c) {
		for (T t : c) {
			if (indexOf(t) >= 0) {
				return true;
			}
		}

		return false;
	}

	public final T get(final T key) {
		final int i = indexOf(key);

		return (i < 0) ? null : values[i];
	}

	public final T greaterThan(final T value) {
		int i = indexOf(value);

		for (i = (i < 0) ? ~i : i+1; i < size; i++) {
			if (values[i].compareTo(value) > 0) {
				return values[i];
			}
		}

		return null;
	}

	public final int indexOf(final T o) {
		int mid, low = 0, high = size;

		while (low < high) {
			mid = (low + high) >>> 1;
			if (values[mid].compareTo(o) < 0) {
		    	low = mid + 1;
			} else {
		    	high = mid;
			}
		}

		return (low < size && values[low].equals(o)) ? low : ~low;
	}

	public final void insert(final int i, final T o) {
		throw new UnsupportedOperationException("Use the add(T) function to insert an element into a ListSortedArray");
	}

	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListSortedArray");
	}

	public final void insertAll(final int i, final Itemizable<? extends T> c) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListSortedArray");
	}

	public final void insertAll(final int i, final Iterable<? extends T> c) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListSortedArray");
	}

	public final boolean remove(final T t) {
		final int i = indexOf(t);

		if (i < 0) {
			return false;
		}

		System.arraycopy(values, i+1, values, i, size-i);
		values[--size] = null;

		return true;
	}

	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		int i, j;
		for (T t : a) {
			i = indexOf(t);

			if (i >= 0) {
				j = i+1;
				System.arraycopy(values, j, values, i, size-j);
				values[--size] = null;
			}
		}

		return origSize != size;
	}

	public final boolean removeAll(final Iterable<? extends T> c) {
		final int origSize = size;

		int i, j;
		for (T t : c) {
			i = indexOf(t);

			if (i >= 0) {
				j = i+1;
				System.arraycopy(values, j, values, i, size-j);
				values[--size] = null;
			}
		}

		return origSize != size;
	}

	public final boolean replace(final T o, final T n) {
		final int oi = indexOf(o);

		if (oi < 0) {
			return false;
		}

		int ni = indexOf(n);
		if (ni < 0) {
			ni = ~ni;
		}

		if (oi < ni) {
			System.arraycopy(values, oi+1, values, oi, --ni-oi);
		} else {
			System.arraycopy(values, ni, values, ni+1, oi-ni);
		}

		values[ni] = n;

		return true;
	}

	public final void set(final int i, final T t) {
		throw new UnsupportedOperationException("Use the add(T) function to put an element into a SortedArray");
	}

	public final void shuffle() {
		throw new UnsupportedOperationException("Cannot shuffle the elements of a SortedArray");
	}

	public final ListSortedArray<T> subList(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final int len = to - from;
		final ListSortedArray<T> a = new ListSortedArray<T>(len);

		System.arraycopy(values, from, a.values, 0, len);
		a.size = len;

		return a;
	}

	@Override
	public T echo(T e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String join(String sep) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<T> subList(int from) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<T> subset(int from) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<T> subset(int from, int to) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<T> toSet() {
		// TODO Auto-generated method stub
		return null;
	}

}
