package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.util.Fast;
import root.util.Random;
import root.util.Safe;

/**
 * Cannot call this a HeapList because of this:
 * 
 * 	http://en.wikipedia.org/wiki/Heap_(data_structure)
 * 
 * One benefit for not implementing List<T> directly is that you
 * are required to use the specific List implementation which also
 * means you have access to any methods unique to the implementation.
 * 
 * TODO:
 * 		+ Add final designation to every non-private method
 * 		+ Add final designation to every method argument that is not used as a local variable
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc
 * 		+ Remove @Override annotations from List<T> methods
 * 		+ Implement Cloneable in all data structures!! (done here)
 * 
 * @author esmith
 *
 * @param <T>
 */
public class ListLinked<T> implements List<T>, Cloneable {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 8388993752865515358L;

	// <><><><><><><><><><><><> Class Attributes <><><><><><><><><><><><><><><>

	private int		size;
	private Node<T>	head;
	private Node<T>	tail;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	public ListLinked() {
		// No-op default constructor
	}

	public ListLinked(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	public final void add(final T o) {
		final Node<T> node = new Node<T>(o);

		if (tail == null) {
			head = node;
		} else {
			tail.next = node;
		}

		tail = node;
		size++;
	}

	@SafeVarargs
	public final void addAll(final T... l) {
		if (l.length > 0) {
			Node<T> first, prev, current;

			first = new Node<T>(l[0]);
			prev = first;
			for (int i=1; i < l.length; i++) {
				current = new Node<T>(l[i]);
				prev.next = current;
				prev = current;
			}

			if (tail == null) {
				head = first;
			} else {
				tail.next = first;
			}

			tail = first;
			size += l.length;
		}
	}

	public final void addAll(final Itemizable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	@Override
	public final void clear() {
		Node.clear(head);

		head = null;
		tail = null;
		size = 0;
	}

	@Override
	public final ListLinked<T> clone() {
		return new ListLinked<>(this);
	}

	public final boolean contains(final T o) {
		for (Node<T> n = head; n != null; n = n.next) {
			if (Safe.equals(n.data, o)) {
				return true;
			}
		}

		return false;
	}

	@SafeVarargs
	public final boolean containsAll(final T... l) {
		Node<T> n;

items:	for (T t : l) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	public final boolean containsAll(final Iterable<? extends T> c) {
		Node<T> n;

items:	for (T t : c) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@SafeVarargs
	public final boolean containsAny(final T... l) {
		Node<T> n;

		for (T t : l) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					return true;
				}
			}
		}

		return false;
	}

	public final boolean containsAny(final Iterable<? extends T> c) {
		Node<T> n;

		for (T t : c) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					return true;
				}
			}
		}

		return false;
	}

	public final T echo(final T o) {
		add(o);
		return o;
	}

	@Override
	public final boolean equals(final Object o) {
		return Node.equals(o, head);
	}

	public final T get(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		return n.data;
	}

	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Node.Descend<>(head, size);
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		return Node.hashCode(head, size);
	}

	public final int indexOf(final T o) {
		int i=0;

		for (Node<T> n = head; n != null; n = n.next, i++) {
			if (Safe.equals(n.data, o)) {
				return i;
			}
		}

		return -1;
	}

	/**
	 * TODO: What happens with the tail when I insert at size-1?
	 */
	public final void insert(final int i, final T o) {
		if (i == size) {
			add(o);
		} else {
			if (i > size || i < 0) {
				throw new IndexOutOfBoundsException(i, size);
			}

			final Node<T> node = new Node<T>(o);

			if (i == 0) {
				node.next = head;
				head = node;
			} else {
				Node<T> prev = head;
				for (int j=1; j < i; j++, prev = prev.next);

				node.next = prev.next;
				prev.next = node;
			}

			size++;
		}
	}

	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		if (a.length > 0) {
			Node<T> first, prev, current;

			first = new Node<T>(a[0]);
			prev = first;
			for (int j=1; j < a.length; j++) {
				current = new Node<T>(a[j]);
				prev.next = current;
				prev = current;
			}
	
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += a.length;
		}
	}

	/**
	 * TODO: Test c.getSize() == 1, i=0, i=size-1
	 */
	public final void insertAll(int i, final Itemizable<? extends T> c) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		if (c.getSize() > 0) {
			Node<T> first = null, prev = null, current;

			for (T t : c) {
				current = new Node<T>(t);

				if (first == null) {
					first = current;
				} else {
					prev.next = current;
				}

				prev = current;
			}
	
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += c.getSize();
		}
	}

	/**
	 * TODO: Test c.isEmpty() == true, i=0, i=size-1
	 */
	public final void insertAll(final int i, final Iterable<? extends T> c) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> first = null, prev = null, current;
		int iterableSize = 0;

		for (T t : c) {
			current = new Node<T>(t);

			if (first == null) {
				first = current;
			} else {
				prev.next = current;
			}

			prev = current;
			iterableSize++;
		}

		if (iterableSize > 0) {
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += iterableSize;
		}
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Node.Ascend<T>(head);
	}

	public final String join(final String sep) {
		// TODO: Why are we using StringBuilder instead of ParamStrBuilder?
		final StringBuilder builder = new StringBuilder((size << 4) + 2);

		builder.append('[');
		if (head != null) {
			builder.append(head.data);
			for (Node<T> node = head.next; node != null; node = node.next) {
				builder.append(sep).append(node.data);
			}
		}

		return builder.append(']').toString();
	}

	public final T last() {
		return (tail == null) ? null : tail.data;
	}

	/**
	 * TODO: Evaluate the use of a global Random class as a potential bottleneck
	 */
	public final T random() {
		final int i = Random.nextIndex(size);

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		return n.data;
	}

	/**
	 * TODO: This implementation looks fishy to me...test the hell out of it
	 */
	public final T remove(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> prev = null, node = head;
		for (int j=0; j < i; j++, prev = node, node = node.next);

		if (head == node) {
			head = head.next;
		}
		if (tail == node) {
			tail = prev;
			tail.next = null;
		}
		if (prev != null) {
			prev.next = node.next;
		}

		final T oldVal = node.data;
		node.data = null;
		node.next = null;
		node = null;
		size--;

		return oldVal;
	}

	/**
	 * TODO: This implementation looks fishy to me...test the hell out of it
	 */
	public final boolean remove(final T o) {
		for (Node<T> prev = null, node = head; node != null; prev = node, node = node.next) {
			if (Safe.equals(node.data, o)) {
				if (head == node) {
					head = head.next;
				}
				if (tail == node) {
					tail = prev;
					tail.next = null;
				}
				if (prev != null) {
					prev.next = node.next;
				}

				node.data = null;
				node.next = null;
				node = null;
				size--;

				return true;
			}
		}

		return false;
	}

	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		for (T t : a) {
			remove(t);
		}

		return origSize != size;
	}

	public final boolean removeAll(final Iterable<? extends T> c) {
		final int origSize = size;

		for (T t : c) {
			remove(t);
		}

		return origSize != size;
	}

	public final boolean replace(final T o, final T n) {
		for (Node<T> i = head; i != null; i = i.next) {
			if (Safe.equals(i.data, o)) {
				i.data = n;
				return true;
			}
		}

		return false;
	}

	public final void set(final int i, final T o) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		n.data = o;
	}

	@SuppressWarnings("unchecked")
	public final void shuffle() {
		if (size > 1) {
			int i=0;

			// 1. Create an array of Nodes to make this easier to implement
			final Node<T>[] nodes = new Node[size];
			for (Node<T> z = head; z != null; z = z.next) {
				nodes[i++] = z;
			}

			// 2. Shuffle the data elements
			for (i=0; i < size; i++) {
				final int j = Random.nextIndex(size);
				final T t = nodes[i].data;
				nodes[i].data = nodes[j].data;
				nodes[j].data = t;
			}
		}
	}

	public final ListLinked<T> subList(final int from) {
		return subList(from, size);
	}

	public final ListLinked<T> subList(final int from, final int to) {
		if (from >= to || from < 0 || to < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final ListLinked<T> l = new ListLinked<T>();

		int j=0;
		Node<T> n = head;
		for (; j < from; j++, n = n.next);

		for (; j < to; j++, n = n.next) {
			l.add(n.data);
		}

		return l;
	}

	public final SetHashed<T> subset(final int from) {
		return subset(from, size);
	}

	public final SetHashed<T> subset(final int from, final int to) {
		if (from >= to || from < 0 || to < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final SetHashed<T> s = new SetHashed<T>(to-from);

		int j=0;
		Node<T> n = head;
		for (; j < from; j++, n = n.next);

		for (; j < to; j++, n = n.next) {
			s.add(n.data);
		}

		return s;
	}

	@SafeVarargs
	public final T[] toArray(T... a) {
		a = Fast.newInstance(a, size);

		int i=0;
		for (Node<T> n = head; n != null; n = n.next) {
			a[i++] = n.data;
		}

		return a;
	}

	public final SetHashed<T> toSet() {
		return subset(0, size);
	}

	@Override
	public final String toString() {
		return Node.toString(head, size);
	}

}
