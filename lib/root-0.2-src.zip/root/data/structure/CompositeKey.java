package root.data.structure;

import java.util.Collection;

import root.lang.Characters;
import root.lang.Extractable;
import root.lang.Itemizable;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * TODO: Test before putting a DONE stamp on it
 * 
 * @author Ed Smith
 */
public class CompositeKey implements Extractable {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 5918255689631311225L;

	// <><><><><><><><><><><><> Class Attributes <><><><><><><><><><><><><><><>

	private final Object[] o;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	public CompositeKey(final Object... keys) {
		o = keys;
	}

	public CompositeKey(final Itemizable<?> keys) {
		o = new Object[keys.getSize()];

		int i=0;
		for (Object k : keys) {
			o[i++] = k;
		}
	}

	public CompositeKey(final Collection<?> keys) {
		o = new Object[keys.size()];

		int i=0;
		for (Object k : keys) {
			o[i++] = k;
		}
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	public final Object[] getKeys() {
		return o;
	}

	@Override
	public final boolean equals(final Object o) {
		try {
			return Safe.equals(o, ((CompositeKey) o).o);
		} catch (ClassCastException e) {
			return false;
		}
	}

	@Override
	public final int hashCode() {
		return Safe.hashCode(o, o.length);
	}

	@Override
	public final void extract(final Characters chars) {
		chars.append(o);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(o.length << 4);
		extract(chars);
		return chars.toString();
	}

}
