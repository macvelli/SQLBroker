package root.data.structure;

import root.lang.Itemizable;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface Stack<T> extends Itemizable<T> {

	T oldest();

	T peek();

	T pop();

	void push(T item);

}
