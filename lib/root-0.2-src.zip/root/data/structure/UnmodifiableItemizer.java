package root.data.structure;

import root.lang.Itemizer;

public final class UnmodifiableItemizer<T> implements Itemizer<T> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 2109606997336664119L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final Itemizer<? extends T> i;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public UnmodifiableItemizer(final Itemizer<? extends T> i) {
		this.i = i;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean hasNext() {
		return i.hasNext();
	}

	@Override
	public final T next() {
		return i.next();
	}

	@Override
	public final void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public final int getIndex() {
		return i.getIndex();
	}

	@Override
	public final Itemizer<T> iterator() {
		return this;
	}

	@Override
	public final void reset() {
		i.reset();
	}

}
