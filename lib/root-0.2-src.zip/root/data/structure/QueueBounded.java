package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;
import root.util.Safe;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Remove @Override annotations from Queue<T> methods (done)
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 * 		+ Check http://math.hws.edu/eck/cs124/javanotes3/c11/s3.html out for some ideas
 * 		+ http://en.wikipedia.org/wiki/Queue_(data_structure)
 * 		+ http://en.wikipedia.org/wiki/Circular_buffer
 * 		+ Make a BoundedQueue implementation as a circular buffer. The difference is that the buffer is fixed in size.
 * 
 * @author esmith
 *
 * @param <T>
 */
public class QueueBounded<T> implements Queue<T> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 4864214666523676077L;

	// <><><><><><><><><><><><> Class Attributes <><><><><><><><><><><><><><><>

	private int	head;
	private int	tail;
	private int	size;
	private final T[] queue;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	public QueueBounded(final int capacity) {
		queue = Clean.newArray(capacity);
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		for (int i=head, j=0; j < size; i = inc(i), j++) {
			queue[i] = null;
		}

		head = tail = size = 0;
	}

	public final T dequeue() {
		if (size == 0) {
			throw new NoSuchElementException("The queue has no elements to dequeue");
		}

		final T t = queue[head];
		queue[head] = null;
		head = inc(head);
		size--;

		return t;
	}

	public final void enqueue(final T t) {
		if (size == queue.length) {
			throw new IllegalStateException("The queue is full and cannot enqueue");
		}

		queue[tail] = t;
		tail = inc(tail);
		size++;
	}

	@Override
	public final boolean equals(final Object o) {
		// TODO Fix this pile of shit
		if (o == null || !(o instanceof Iterable)) {
			return false;
		}

		final Iterable<?> i = (Iterable<?>) o;

		int index = head;
		for (Object t : i) {
			if (Safe.notEqual(queue[index], t)) {
				return false;
			}
		    index = inc(index);
		}

		return index == tail;
	}

	public final int getCapacity() {
		return queue.length;
	}

	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Descend();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (int i=head, j=0; j < size; i = inc(i), j++) {
			if (queue[i] != null) {
				h <<= 1;
				h ^= queue[i].hashCode();
			}
		}

		return h;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	public final T peek() {
		return queue[head];
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		for (int i=head, j=0; j < size; i = inc(i), j++) {
			builder.separator(1).append(queue[i]);
		}
		builder.append(']');

		return builder.toString();
	}

	//  <><><><><><><><><><><><>< Private Methods ><><><><><><><><><><><><><><>

	private int inc(int i) {
		return (++i == queue.length) ? 0 : i;
	}

	//  <><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><><>

	private class Ascend implements Itemizer<T> {

		private int i = head, j;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			final T t = queue[i];
			i = inc(i);
			j++;

			return t;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		public final int getIndex() {
			return j;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = head;
			j = 0;
		}
		
	}	// End Ascend

	private class Descend implements Itemizer<T> {

		private int i = tail, j;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			final T t = queue[i];
			i = (--i < 0) ? queue.length-1 : i;
			j++;

			return t;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return j;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = tail;
			j = 0;
		}

	}	// End Descend

}
