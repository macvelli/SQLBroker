package root.data.structure;

import root.lang.Itemizable;

/**
 * TODO:
 * 		+ Remove public designation from method declarations (done)
 * 		+ Rename generic type E to generic type T (done)
 * 		+ Seems like Extractable should only be implemented when the generic
 * 		  types enforce elements to extend it since it's useless otherwise
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface List<T> extends Itemizable<T> {

	void add(T e);

	void addAll(T... a);

	void addAll(Itemizable<? extends T> c);

	void addAll(Iterable<? extends T> c);

	boolean contains(T e);

	boolean containsAll(T... a);

	boolean containsAll(Iterable<? extends T> c);

	boolean containsAny(T... a);

	boolean containsAny(Iterable<? extends T> c);

	T echo(T e);

	T get(int i);

	int indexOf(T e);

	void insert(int i, T e);

	void insertAll(int i, T... a);

	void insertAll(int i, Itemizable<? extends T> c);

	void insertAll(int i, Iterable<? extends T> c);

	String join(String sep);

	T last();

	T random();

	T remove(int i);

	boolean remove(T e);

	boolean removeAll(T... a);

	boolean removeAll(Iterable<? extends T> c);

	boolean replace(T o, T n);

	void set(int i, T e);

	void shuffle();

	List<T> subList(int from);

	/**
	 * http://teddziuba.com/2008/09/java-sublist-gotcha.html
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	List<T> subList(int from, int to);

	Set<T> subset(int from);

	Set<T> subset(int from, int to);

	T[] toArray(T... a);

	Set<T> toSet();

}
