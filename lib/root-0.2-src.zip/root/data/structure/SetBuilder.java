package root.data.structure;

import root.lang.Builder;

public final class SetBuilder<T> implements Builder {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final SetHashed<T> set;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public SetBuilder() {
		set = new SetHashed<>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final SetBuilder<T> add(final T o) {
		set.add(o);
		return this;
	}

	@SafeVarargs
	public final SetBuilder<T> addAll(final T... a) {
		set.addAll(a);
		return this;
	}

	public final SetBuilder<T> addAll(final Iterable<? extends T> c) {
		set.addAll(c);
		return this;
	}

	@Override
	public final SetImmutable<T> build() {
		return new SetImmutable<>(set.clone());
	}

}
