package root.data.validation;

import root.lang.ParamStr;

public class InvalidFormatException extends RuntimeException {

	private static final long serialVersionUID = -6176225607170169664L;

	public InvalidFormatException(final String message, final Object... params) {
		super(ParamStr.format(message, params));
	}

}	// End InvalidFormatException
