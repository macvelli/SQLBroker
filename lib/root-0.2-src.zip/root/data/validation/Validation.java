package root.data.validation;

public class Validation {

	public boolean isValid(final String value) {
		return value != null && value.length() > 0;
	}

}	// End Validation
