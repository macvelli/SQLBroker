package root.data.validation;

import java.util.HashMap;
import java.util.Map;

import root.data.structure.List;
import root.data.structure.ListArray;

public class Validator {

	private final ListArray<Field> fieldList;

	public Validator() {
		fieldList = new ListArray<>();
	}

	public Field add(final String name, final String term) {
		return fieldList.echo(new Field(name, term));
	}

	public List<FieldError> validate(final Map<String, String[]> data) {
		final Request request = new Request(data);

		for (Field f : fieldList)
			f.validate(request);

		return request.getErrors();
	}

//	ActionBean: NonStockActionBean
//	Event: updateReq
//	Request Parameters:
//		nonStockReq.vendorCatNum = 1
//		__fp = zx7s_e0AVf4=
//		nonStockReq.promisedDateDay = 
//		nonStockReq.patientInfo.capExReqNum = 
//		nonStockReq.EOMFlag = false
//		nonStockReq.entityCode = PHA
//		nonStockReq.needDateMonth = 
//		nonStockReq.deliverToDept = 8681
//		nonStockReq.purchUnit = EA
//		nonStockReq.highPriority = false
//		nonStockReq.GLAcctNum = 
//		nonStockReq.patientInfo.modelSerialNum = 
//		nonStockReq.purchDeptCode = 8681
//		nonStockReq.needDateDay = 
//		_sourcePage = nIIJZ4Tt5pnuimkEWLn2qoH-ZlB-qGwcUngCB-EwNzQ=
//		nonStockReq.qtyOrdered = 1
//		nonStockReq.patientInfo.physnName = 
//		nonStockReq.patientInfo.patientName = 
//		userName = 
//		nonStockReq.primaryKey = 29334
//		nonStockReq.naturalExpClass = 4060
//		nonStockReq.patientInfo.patientEncntrNum = 
//		nonStockReq.invoiceFlag = false
//		nonStockReq.promisedDateYear = 
//		nonStockReq.vendorNum = 1
//		nonStockReq.needDateYear = 
//		nonStockReq.promisedDateMonth = 
//		nonStockReq.itemDesc2 = 
//		nonStockReq.itemDesc1 = 1
//		nonStockReq.deliverToIndiv = MATERIALS MANAGEMENT
//		nonStockReq.POType = 
//		nonStockReq.itemDesc3 = 
//		updateReq = Update
//		nonStockReq.reqNum = 40002524
//		nonStockReq.purchMeas = 00001
//		nonStockReq.lineItemPrice = 9999999.99
//		nonStockReq.chargeToDept = ABCD
//		nonStockReq.patientInfo.changeTicketNum = 
	public static void main(String[] args) {
		final Validator v = new Validator();

		v.add("nonStockReq.chargeToDept", "Charge To Department").required();

		HashMap<String, String[]> request = new HashMap<String, String[]>();
		request.put("nonStockReq.chargeToDept", new String[] {"abc"});
		final List<FieldError> errors = v.validate(request);

		for (FieldError e : errors)
			System.out.println("Field Name: " + e.getName() + ", Error Msg: " + e.getMsg());
	}

}	// End Validator
