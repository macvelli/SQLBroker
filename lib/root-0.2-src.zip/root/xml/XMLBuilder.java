package root.xml;

import root.data.structure.StackArray;
import root.data.structure.Stack;

public class XMLBuilder {

	public static final String EMPTY_STR = "";

	private Element current;
	private final Element root;
	private final Stack<Element> elementStack;

	public XMLBuilder(final String rootElementName) {
		root = new Element(rootElementName);
		current = root;
		elementStack = new StackArray<Element>();
	}

	public void addAttribute(final String name, final String value) {
		current.addAttribute(name, value);
	}

	public void addElement(final String name, final Object value) {
		current.addChild(name, (value == null) ? EMPTY_STR : value.toString());
	}

	public void addElement(final String name, final String value) {
		current.addChild(name, value);
	}

	public void addChild(final String name) {
		Element e = current.addChild(name);
		elementStack.push(current);
		current = e;
	}

	public void closeChild() {
		current = elementStack.pop();
	}

	public void closeChild(final String childName) {
		do {
			current = elementStack.pop();
		} while (!current.getName().equals(childName));
	}

	public void closeChildren() {
		current = elementStack.oldest();
		elementStack.clear();
	}

	@Override
	public String toString() {
		return root.toString();
	}

}	// End XMLBuilder
