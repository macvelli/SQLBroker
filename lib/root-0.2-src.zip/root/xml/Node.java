package root.xml;

import root.lang.Extractable;

abstract class Node implements Extractable {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	protected final String name;
	protected String value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	protected Node(final String name) {
		this.name = name;
	}

	protected Node(final String name, final String value) {
		this.name = name;
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

}
