package root.xml;

import root.data.structure.List;
import root.data.structure.ListLinked;
import root.lang.Characters;
import root.lang.ParamStrBuilder;

/*
 * - Can an Element have an attribute and a child element with the same name?
 */
public class Element extends Node {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private ListLinked<Attribute> attributeList;
	private ListLinked<Element> elementList;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Element(final String name) {
		super(name);
		attributeList = new ListLinked<>();
		elementList = new ListLinked<>();
	}

	public Element(final String name, final String value) {
		super(name, value);
		attributeList = new ListLinked<>();
		elementList = new ListLinked<>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public void addAttribute(final String name, final String value) {
		attributeList.add(new Attribute(name, value));
	}

	public void addChild(final Element e) {
		elementList.add(e);
	}

	public Element addChild(final String name) {
		return elementList.echo(new Element(name));
	}

	public void addChild(final String name, final String value) {
		elementList.add(new Element(name, value));
	}

	public List<Attribute> getAttributes() {
		return attributeList;
	}

	public Element getFirstChild() {
		return (elementList.isEmpty()) ? null : elementList.get(0);
	}

	@Override
	public final void extract(final Characters chars) {
		// 1. Create the opening element tag complete with any attributes
		chars.append('<').append(name);
		for (Attribute a : attributeList) {
			chars.append(' ').append(a);
		}

		// 2. Either append the element value or all of its sub-elements
		if (value != null) {
			chars.append('>').append(value);
		} else if (!elementList.isEmpty()) {
			chars.append('>');
			for (Element e : elementList) {
				chars.append(e);
			}
		}

		// 3. Close off the element tag
		if (value == null && elementList.isEmpty()) {
			chars.append('/','>');
		} else {
			chars.append('<','/').append(name).append('>');
		}
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder();
		extract(chars);
		return chars.toString();
	}

}
