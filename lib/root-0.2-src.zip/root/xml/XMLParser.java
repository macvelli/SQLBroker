package root.xml;

import root.data.structure.StackArray;
import root.data.structure.IntStack;
import root.data.structure.Stack;

/*
 * Visual Basic
 * 
 * Module Module1
 * 
 * Sub Main()
 * Dim doc = XDocument.Load("file.xml")
 * 
 * Console.WriteLine("Root element :" & doc.Root.Name.ToString)
 * Console.WriteLine(-------------------)
 * 
 * For Each staff In doc
 *     Console.WriteLine("First Name : " & staff..Value)
 *     Console.WriteLine("Last Name : " & staff..Value)
 *     Console.WriteLine("Nick Name : " & staff..Value)
 *     Console.WriteLine("Salary : " & staff..Value)
 * Next
 * End Sub
 * 
 * End Module
 */
// http://java.sun.com/developer/technicalArticles/xml/JavaTechandXML_part3/
// TODO: Relies on a standardized XML format input (is this the XML object?)
public class XMLParser {

	public static final Element parse(final String xml) {
		final Stack<Element> elementStack = new StackArray<Element>();
		final IntStack startTagOffsetStack = new IntStack();
		// TODO: Does it make sense to have an XML class that contains both the String and char[] values?  Only if I can create the char[] before the String
		final char[] c = xml.toCharArray();
		int i = 0, j, startOffset = 0, endOffset, valueOffset = 0, attrNameStartOffset;
		boolean wellFormed = true;
		String value;
		Element e = null;

		while (i < c.length) {
			if (c[i] == '<') {
				// Found a tag -- save off value first
				if (valueOffset > 0) {
					value = xml.substring(valueOffset, i);
					valueOffset = 0;
				} else {
					value = null;
				}

				i++;
				if (c[i] == '/') {
					// Found an end tag
					endOffset = ++i;

					// Validate Element is well-formed
					e = elementStack.pop();
					startOffset = startTagOffsetStack.pop();

					for (j = 0; c[++i] != '>'; j++) {
						wellFormed = wellFormed && c[startOffset + j] == c[endOffset + j];
					}
					wellFormed = wellFormed && e.name.length() == (i-endOffset);

					if (!wellFormed) {
						// Ooops, there was a problem matching up the start and end tags
						throw new RuntimeException("Invalid XML entry " + xml.substring(startOffset-1, i+1));
					}

					e.value = value;
					i++;
				} else {
					// Found a start tag
					startOffset = i;
					while (c[++i] != '/' && c[i] != '>' && c[i] != ' ');
					e = new Element(xml.substring(startOffset, i));
					if (!elementStack.isEmpty()) {
						elementStack.peek().addChild(e);
					}

					if (c[i] == ' ') {
						// This start tag has attributes
						do {
							attrNameStartOffset = ++i;
							while (c[++i] != '=');
							endOffset = i;
							i += 2;
							valueOffset = i;
							for (; c[i] != '"'; i++);
							e.addAttribute(xml.substring(attrNameStartOffset, endOffset), xml.substring(valueOffset, i++));
						} while (c[i] == ' ');
						valueOffset = 0;
					}

					if (c[i] == '/') {
						// Element end shortcut
						i++;
					} else {
						// Element has content
						elementStack.push(e);
						startTagOffsetStack.push(startOffset);
					}

					i++;
				}
			} else if (valueOffset == 0) {
				// Found a value
				valueOffset = i++;
			} else {
				i++;
			}
		}

		return e;
	}

}	// End XMLParser
