package root.xml;

import root.lang.Characters;
import root.lang.ParamStrBuilder;

public final class Attribute extends Node {

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Attribute(final String name, final String value) {
		super(name, value);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append(name).append('=');
		chars.append('"').append(value).append('"');
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(name.length() + value.length() + 3);
		extract(chars);
		return chars.toString();
	}

}
