package root.timer;

import java.util.Date;

import root.data.structure.MapHashed;

// TODO: This guy needs a pimped out toString() method so I don't have to write out the Profilers every time I test something, just System.out.println(Watch) and be done with it
public final class Watch {

	private boolean							running;

	private boolean							failed;

	private long							start;

	private long							stop;

	private Date							begin;

	private Date							end;

	private String							name;

	private final Profiler					total;

	private final MapHashed<String, Profiler>	profilerMap;

	public Watch() {
		total = new Profiler();
		profilerMap = new MapHashed<String, Profiler>();
	}

	public Watch(final String name) {
		this();
		this.name = name;
	}

	public long elapsed() {
		return (stop - start);
	}

	public boolean isRunning() {
		return running;
	}

	public String freeMemory(final String task) {
		final StringBuilder builder = new StringBuilder(name);

		builder.append(' ').append(task).append(':').append(' ');
		builder.append(Runtime.getRuntime().freeMemory() >> 10).append('K');

		return builder.toString();
	}

	public void mark(final String profile) {
		stop = System.currentTimeMillis();
		total.accrue(this);
		profilerMap.get(profile, Profiler.class).accrue(this);
		start = System.currentTimeMillis();
	}

	public void start() {
		if (!running) {
			running = true;
			start = System.currentTimeMillis();
			if (begin == null)
				begin = new Date(start);
		}
	}

	public void stop(final String... profiles) {
		if (running) {
			stop = System.currentTimeMillis();
			end = new Date(stop);
			total.accrue(this);

			for (String s : profiles)
				profilerMap.get(s, Profiler.class).accrue(this);
			running = false;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Date getStartDate() {
		return begin;
	}

	public Date getEndDate() {
		return end;
	}

	public void failed() {
		failed = true;
	}

	public boolean hasFailed() {
		return failed;
	}

	public int getNumProcessed() {
		return (int) total.getResultStats().sum();
	}

	public void setNumProcessed(final int processed) {
		total.getResultStats().add(processed);
	}

	public Profiler getProfile(final String profile) {
		return profilerMap.get(profile);
	}

	public Profiler getTotal() {
		return total;
	}

}	// End Watch
