package root.timer;

public class Expire {

	/** The number of milliseconds before the <code>Timer</code> expires		*/
	private long expiry;

	/** The start time of the <code>Timer</code>								*/
	private long startTime;

	/** The start time of the <code>Timer</code>								*/
	private long elapsed;

	/**
	 * Creates a <code>Timer</code> instance initialized with the
	 * {@link System} current time in milliseconds.
	 */
	public Expire() {
		super();
		this.startTime = System.currentTimeMillis();
	}

	/**
	 * Creates a <code>Timer</code> instance initialized with a default
	 * <code>expiry</code> value.
	 * 
	 * @param expiry	The number of milliseconds before the <code>Timer</code> expires.
	 */
	public Expire(final long expiry) {
		this();
		this.expiry = expiry;
	}

	/**
	 * Resets the <code>Timer</code> start time to the {@link System} current
	 * time in milliseconds.
	 */
	public void reset() {
		startTime = System.currentTimeMillis();
	}

	/**
	 * Sets the <code>Timer</code> expiry.
	 * 
	 * @param expiry	The expiry value to set.
	 */
	public void setExpiry(final long expiry) {
		this.expiry = expiry;
	}

	/**
	 * Returns <code>true</code> if the <code>expiry</code> is less than
	 * or equal to the difference between the current system time and the
	 * <code>Timer</code> start time.
	 * <p>
	 * The <code>Timer</code> only expires if the <code>expiry</code>
	 * is greater than zero.
	 *
	 * @return <code>true</code> if time expired, <code>false</code> otherwise.
	 */
	public boolean isExpired() {
		elapsed = System.currentTimeMillis() - startTime;
		return (expiry > 0 && elapsed >= expiry);
	}

	/**
	 * Returns the amount of time remaining before the timer expires.
	 *
	 * @return the amount of time remaining before the timer expires.
	 */
	public long remaining() {
		return (expiry > 0) ? expiry - elapsed : Long.MAX_VALUE;
	}

}	// End Timer
