package root.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

public final class Root {

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Unused Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//	public static String toString(final Object[] objs, final String sep) {
//	return (objs == null) ? "[]" : Root.toString(objs, sep, objs.length);
//}

//public static String toString(final Object[] objs, final String sep, final int len) {
//	if (len == 0)
//		return "[]";
//
//	Object o;
//	int strLen = 2;
//	final String[] strs = new String[len];
//	for (int i=0; i < len; i++) {
//		o = objs[i];
//		strs[i] = (o == null) ? NULL : o.toString();
//		strLen += strs[i].length();
//	}
//
//	final int sepLen = sep.length();
//	final char[] c = new char[strLen + ((len - 1) * sepLen)];
//	strLen = strs[0].length();
//
//	c[0] = '[';
//	strs[0].getChars(0, strLen, c, 1);
//	int j = strLen + 1;
//	for (int i=1; i < len; i++) {
//		sep.getChars(0, sepLen, c, j);
//		j += sepLen;
//		strLen = strs[i].length();
//		strs[i].getChars(0, strLen, c, j);
//		j += strLen;
//	}
//	c[j] = ']';
//
//	return new String(c);
//}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~ Core Java Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Generates a JDK proxy instance to the interface class backed by the
	 * provided invocation handler.  Very useful for aspect-oriented
	 * programming.
	 * 
	 * @param clazz the interface to proxy.
	 * @param h the proxy invocation handler.
	 * @return a new proxy instance of the interface backed by the invocation handler.
	 */
	@SuppressWarnings("unchecked")
	public static<T> T proxy(final Class<T> clazz, final InvocationHandler h) {
		return (T) Proxy.newProxyInstance(clazz.getClassLoader(), new Class[] {clazz}, h);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ String Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Returns the substring of the {@link String} parameter found between the
	 * open and close characters.
	 * <p>
	 * A <code>null</code> is returned if either the open or close characters
	 * cannot be found, or if the close character occurs before the open
	 * character.
	 * 
	 * @param str	The {@link String} to parse for the substring.
	 * @param open	The opening charater.
	 * @param close	The closing character.
	 * @return	The {@link String} found between the open and close characters.
	 */
	public static String between(final String str, final char open, final char close) {
		if (str != null) {
			final int begin = str.indexOf(open, 0) + 1;
			if (begin > 0) {
				final int end = str.indexOf(close, begin);
				if (end > begin) return str.substring(begin, end);
			}
		}

		return null;
	}

}	// End Root
