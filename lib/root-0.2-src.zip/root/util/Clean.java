package root.util;

public final class Clean {

	@SuppressWarnings("unchecked")
	public static final <T> T[] newArray(final int size) {
		return (T[]) new Object[size];
	}

	public static final <T> T newInstance(final Class<T> clazz) {
		try {
			return clazz.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
