package root.util;

import java.util.Iterator;

import root.data.structure.ListArray;

public class PairedIterator<T> implements Iterable<PairedIterator.Each<T>> {

	private final Iterable<T> original;

	private final Iterable<T> updated;

	public PairedIterator(final Iterable<T> original, final Iterable<T> updated) {
		this.original = original;
		this.updated = updated;
	}

	public Iterator<Each<T>> iterator() {
		return new Each<T>(original.iterator(), updated.iterator());
	}

	public static class Each<E> implements Iterator<Each<E>> {

		private E o;
		private E u;

		private final Iterator<E> oItr;
		private final Iterator<E> uItr;

		private Each(final Iterator<E> original, final Iterator<E> updated) {
			this.oItr = original;
			this.uItr = updated;
		}

		public E getOriginal() {
			return o;
		}

		public E getUpdated() {
			return u;
		}

		public boolean hasNext() {
			return oItr.hasNext() || uItr.hasNext();
		}

		public Each<E> next() {
			o = (oItr.hasNext()) ? oItr.next() : null;
			u = (uItr.hasNext()) ? uItr.next() : null;

			return this;
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

	}	// End Each

	public static void main(String[] args) {
		ListArray<String> a1 = new ListArray<String>("Foo", "ABC", "XYZ");
		ListArray<String> a2 = new ListArray<String>("Bar", "123", "789", "ZZZ");

		for (Each<String> s : new PairedIterator<String>(a1, a2))
			System.out.println(s.getOriginal() + " " + s.getUpdated());
	}

}	// End PairedIterator
