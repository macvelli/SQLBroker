/*
 * Open source license text goes here.
 */

package root.util;

import java.sql.*;

/**
 * 
 * @author esmith
 */
public final class Jdbc {

	public static final void close(final Connection con) {
		try { con.close(); }  catch (Exception ex) {}
	}

	public static final void close(final Statement stmt) {
		try { stmt.close(); } catch (Exception ex) {}
	}

	public static final void close(final Statement stmt, final ResultSet rs) {
		try { rs.close(); }	  catch (Exception ex) {}
		try { stmt.close(); } catch (Exception ex) {}
	}

	public static final void close(final Connection con, final Statement stmt) {
		try { stmt.close(); } catch (Exception ex) {}
		try { con.close(); }  catch (Exception ex) {}
	}

	public static final void close(final Connection con, final Statement stmt, final ResultSet rs) {
		try { rs.close(); }	  catch (Exception ex) {}
		try { stmt.close(); } catch (Exception ex) {}
		try { con.close(); }  catch (Exception ex) {}
	}

}
