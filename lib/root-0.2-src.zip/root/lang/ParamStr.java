package root.lang;

import root.data.structure.CharArrayCollector;
import root.util.Safe;

// TODO: Document!!
// TODO: Needs optimization!!
public class ParamStr {

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Static Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	// TODO: Need an Extractable... params method that uses ParamStrBuilder to build the String
	public static String format(final String msg, final Object... params) {
		if (params.length == 0)
			return msg;
		else {
			// Turn all params into strings and calc message length
			// TODO: Make this Fast!
			final char[] m = msg.toCharArray();
			final String[] strs = Safe.valueOf(params);
			final char[] c = new char[m.length - params.length - (params.length << 1) + Safe.length(strs)];

			// Build the formatted message
			int i = 0, j = 0, srcPos = 0, destPos = 0, len;
			while (true)
				if (m[i++] == '{' && m[i] == 'P' && m[++i] == '}') {
					len = i - srcPos - 2;
					System.arraycopy(m, srcPos, c, destPos, len);
					destPos += len;
					strs[j].getChars(0, strs[j].length(), c, destPos);
					destPos += strs[j++].length();
					srcPos = ++i;
					if (j == strs.length) {
						System.arraycopy(m, srcPos, c, destPos, m.length - srcPos);
						return new String(c);
					}
				}
		}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Class Definition ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private int		size;
	final char[][]	segs;

	public ParamStr(final String msg) {
		// TODO: Make this Fast!
		final char[] m = msg.toCharArray();
		final CharArrayCollector segments = new CharArrayCollector();

		char[] c;
		int i = 0, srcPos = 0, len;
		final int end = m.length - 2;
		while (i < end) {
			if (m[i++] == '{' && m[i] == 'P' && m[++i] == '}') {
				len = i - srcPos - 2;
				c = new char[len];
				System.arraycopy(m, srcPos, c, 0, len);
				segments.add(c);
				srcPos = ++i;
				size += len;
			}
		}

		len = m.length - srcPos;
		c = new char[len];
		System.arraycopy(m, srcPos, c, 0, len);
		segments.add(c);
		size += len;

		segs = segments.toArray();
	}

	// TODO: Need an Extractable... params method that uses ParamStrBuilder to build the String
	public String build(final Object... objs) {
		final String[] strs = new String[objs.length];
		int strsLen = 0;
		for (int i=0; i < objs.length; i++) {
			strs[i] = objs[i].toString();
			strsLen += strs[i].length();
		}
		final char[] c = new char[size + strsLen];

		char[] z;
		String s;
		int i = 0, destPos = 0;
		while (true) {
			z = segs[i];
			System.arraycopy(z, 0, c, destPos, z.length);
			destPos += z.length;

			if (i == objs.length)
				return new String(c);

			s = strs[i++];
			s.getChars(0, s.length(), c, destPos);
			destPos += s.length();
		}
	}

}	// End ParamStr
