package root.lang;

//TODO: Make every possible data class, collection class, etc implement this method
//TODO: Ok so I have proven that checking for instanceof Extractor on an Object is not cost-effective..but what about having an ExtractorList that only takes objects that implement Extractor?
public interface Extractable {

	public void extract(Characters c);

}
