package root.lang.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// TODO: Pretty print this shit, and then figure out how to XML it so an XSLT can show it in a browser
public class ClassInfo {

	public static void printConstructors(final Class<?> clazz) {
		final Constructor<?>[] constructors = clazz.getDeclaredConstructors();

		// TODO: private, package, protected, public

		for (Constructor<?> c : constructors) {
			System.out.println(c);
		}
	}

	public static void printDeclarations(final Class<?> clazz) {
		ClassInfo.printFields(clazz);
		ClassInfo.printConstructors(clazz);
		ClassInfo.printMethods(clazz);
	}

	public static void printFields(final Class<?> clazz) {
		final Field[] fields = clazz.getDeclaredFields();

		// TODO: private, package, protected, public, static/instance

		for (Field f : fields) {
			System.out.println(f);
		}
	}

	public static void printMethods(final Class<?> clazz) {
		final Method[] methods = clazz.getDeclaredMethods();

		// TODO: private, package, protected, public, static/instance

		for (Method m : methods) {
			System.out.println(m);
		}
	}

	public static void main(String[] args) {
		ClassInfo.printDeclarations(String.class);
	}

}	// End ClassInfo
