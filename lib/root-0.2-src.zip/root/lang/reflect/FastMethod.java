package root.lang.reflect;

import java.lang.reflect.Method;

import sun.reflect.MethodAccessor;

public class FastMethod {

	private static final ObjectField<Method, MethodAccessor> methodAccessor = new ObjectField<Method, MethodAccessor>(Method.class, "methodAccessor");

	private static final Method acquireMethodAccessor = getMethod(Method.class, "acquireMethodAccessor");

	private final MethodAccessor invoker;

	public static final Method getMethod(final Class<?> clazz, final String methodName, final Class<?>... params) {
		try {
			final Method m = clazz.getDeclaredMethod(methodName, params);
			if (!m.isAccessible()) {
				m.setAccessible(true);
			}
			return m;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public FastMethod(final Class<?> clazz, final String methodName, final Class<?>... params) throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
		final Method m = getMethod(clazz, methodName, params);
		try {
			acquireMethodAccessor.invoke(m);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		invoker = methodAccessor.get(m);
	}

	public Object invoke(final Object obj, final Object... args) {
		try {
			return invoker.invoke(obj, args);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	final static char[] digits = {'0','1','2','3','4','5','6','7','8','9'};

	final static char[] minValue = {'-','2','1','4','7','4','8','3','6','4','8'};

	static void getChars(int i, int index, char[] buf) {
		int q, r;
		int charPos = index;
		final boolean sign = (i < 0);

		if (sign) {
			if (i == Integer.MIN_VALUE) {
				System.arraycopy(minValue, 0, buf, index-11, 11);
				return;
			}

			i = -i;
		}

		do {
			q = i / 10;
			r = i - ((q << 3) + (q << 1));
			buf[--charPos] = digits[r];
			i = q;
		} while (i > 0);

		if (sign) {
			buf [--charPos] = '-';
		}
	}

	static String toString(final int i) {
        int size = stringSize(i);
        char[] buf = new char[size];
        getChars(i, size, buf);

		return null;
	}

	static int stringSize(final int i) {
		if (i < 0) {
			if (i > -10) return 2;
			if (i > -100) return 3;
			if (i > -1000) return 4;
			if (i > -10000) return 5;
			if (i > -100000) return 6;
			if (i > -1000000) return 7;
			if (i > -10000000) return 8;
			if (i > -100000000) return 9;
			if (i > -1000000000) return 10;

			return 11;
		}

		if (i < 10) return 1;
		if (i < 100) return 2;
		if (i < 1000) return 3;
		if (i < 10000) return 4;
		if (i < 100000) return 5;
		if (i < 1000000) return 6;
		if (i < 10000000) return 7;
		if (i < 100000000) return 8;
		if (i < 1000000000) return 9;

		return 10;
	}

	public static void main(String[] args) throws Exception {
		long start, end;
		Integer i = Integer.valueOf(141241);
		char[] buf = new char[6];

		Method getChars = Integer.class.getDeclaredMethod("getChars", int.class, int.class, char[].class);
		getChars.setAccessible(true);

		// Warm up the JVM
		for (int j=0; j < 1000000; j++) {
	        getChars.invoke(null, i, 6, buf);
		}

		System.out.print("Method getChars():     ");
		start = System.nanoTime();
		for (int j=0; j < 10000000; j++) {
	        getChars.invoke(null, i, 6, buf);
		}
		end = System.nanoTime();

		System.out.println(end-start);

		FastMethod fastGetChars = new FastMethod(Integer.class, "getChars", int.class, int.class, char[].class);

		System.out.print("FastMethod getChars(): ");
		start = System.nanoTime();
		for (int j=0; j < 10000000; j++) {
			fastGetChars.invoke(null, i, 6, buf);
		}
		end = System.nanoTime();

		System.out.println(end-start);

		System.out.print("Local getChars():      ");
		start = System.nanoTime();
		for (int j=0; j < 10000000; j++) {
			getChars(141241, 6, buf);
		}
		end = System.nanoTime();

		System.out.println(end-start);

		System.out.println(new String(buf));
	}

}
