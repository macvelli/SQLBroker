package root.lang.reflect;

import java.lang.reflect.Constructor;

public class TestStringPackageConstructor {

	public static void main(String[] args) throws Exception {
		Constructor<String> c = String.class.getDeclaredConstructor(int.class, int.class, char[].class);

		System.out.println(c);
		c.setAccessible(true);

		String foo = "Foo";
		ObjectField<String, char[]> value = new ObjectField<String, char[]>(String.class, "value");
		char[] ch = value.get(foo);
		String bar = c.newInstance(0, ch.length, ch);

		System.out.println(foo + " " + bar);
	}

}	// End TestStringPackageConstructor
