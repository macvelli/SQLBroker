package root.lang.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import sun.misc.Unsafe;

//TODO: This is needed since I cannot get the real static primitive field via java.lang.reflect.Field
public class StaticPrimitiveField {

	private static final Unsafe unsafe = getUnsafe();

	private final long offset;

	private final Object base;

	public StaticPrimitiveField(final Class<?> clazz, final String fieldName) {
		try {
			final Field f = clazz.getDeclaredField(fieldName);

			if (!Modifier.isStatic(f.getModifiers())) {
				throw new RuntimeException("PrimitiveStaticField does not support instance fields");
			}

			offset = unsafe.staticFieldOffset(f);
			base =  unsafe.staticFieldBase(f);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public boolean getBoolean() {
		return unsafe.getBoolean(base, offset);
	}

	public void setBoolean(final boolean value) {
		unsafe.putBoolean(base, offset, value);
	}

	public byte getByte() {
		return unsafe.getByte(base, offset);
	}

	public void setByte(final byte value) {
		unsafe.putByte(base, offset, value);
	}

	public char getChar() {
		return unsafe.getChar(base, offset);
	}

	public void setChar(final char value) {
		unsafe.putChar(base, offset, value);
	}

	public double getDouble() {
		return unsafe.getDouble(base, offset);
	}

	public void setDouble(final double value) {
		unsafe.putDouble(base, offset, value);
	}

	public float getFloat() {
		return unsafe.getFloat(base, offset);
	}

	public void setFloat(final float value) {
		unsafe.putFloat(base, offset, value);
	}

	public int getInt() {
		return unsafe.getInt(base, offset);
	}

	public void setInt(final int value) {
		unsafe.putInt(base, offset, value);
	}

	public long getLong() {
		return unsafe.getLong(base, offset);
	}

	public void setLong(final long value) {
		unsafe.putLong(base, offset, value);
	}

	public short getShort() {
		return unsafe.getShort(base, offset);
	}

	public void setShort(final short value) {
		unsafe.putShort(base, offset, value);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static Unsafe getUnsafe() {
		try {
			Field field = Unsafe.class.getDeclaredField("theUnsafe");
			field.setAccessible(true);
			return (Unsafe) field.get(null);
		} catch (Exception ex) {
			throw new RuntimeException("Cannot get Unsafe instance", ex);
		}
	}

	public static void main(String[] args) {
		final int numTries = 20;
		long[] test1 = new long[numTries];
		long start;
		StaticPrimitiveField serialVersionUID = new StaticPrimitiveField(String.class, "serialVersionUID");

		int j;
		for (int i=0; i < numTries; i++) {
			start = System.nanoTime();
			for (j=0; j < 10000000; j++) {
				serialVersionUID.getLong();
			}
			test1[i] = System.nanoTime()-start;
		}

		System.out.println(Arrays.toString(test1));
		// TODO: Now can do summations, averages, min/max, and aggregate percentage ratio comparisons 
	}

}	// End PrimitiveStaticField
