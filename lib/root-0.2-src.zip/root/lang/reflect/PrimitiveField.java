package root.lang.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import root.tools.Profiler;
import sun.misc.Unsafe;

public class PrimitiveField<C> {

	private static final Unsafe unsafe = getUnsafe();

	private final long offset;

	public PrimitiveField(final Class<C> clazz, final String fieldName) {
		try {
			final Field f = clazz.getDeclaredField(fieldName);

			if (Modifier.isStatic(f.getModifiers())) {
				throw new RuntimeException("FastField does not support static fields");
			}

			offset = unsafe.objectFieldOffset(f);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public boolean getBoolean(final C c) {
		return unsafe.getBoolean(c, offset);
	}

	public void setBoolean(final C c, final boolean value) {
		unsafe.putBoolean(c, offset, value);
	}

	public byte getByte(final C c) {
		return unsafe.getByte(c, offset);
	}

	public void setByte(final C c, final byte value) {
		unsafe.putByte(c, offset, value);
	}

	public char getChar(final C c) {
		return unsafe.getChar(c, offset);
	}

	public void setChar(final C c, final char value) {
		unsafe.putChar(c, offset, value);
	}

	public double getDouble(final C c) {
		return unsafe.getDouble(c, offset);
	}

	public void setDouble(final C c, final double value) {
		unsafe.putDouble(c, offset, value);
	}

	public float getFloat(final C c) {
		return unsafe.getFloat(c, offset);
	}

	public void setFloat(final C c, final float value) {
		unsafe.putFloat(c, offset, value);
	}

	public int getInt(final C c) {
		return unsafe.getInt(c, offset);
	}

	public void setInt(final C c, final int value) {
		unsafe.putInt(c, offset, value);
	}

	public long getLong(final C c) {
		return unsafe.getLong(c, offset);
	}

	public void setLong(final C c, final long value) {
		unsafe.putLong(c, offset, value);
	}

	public short getShort(final C c) {
		return unsafe.getShort(c, offset);
	}

	public void setShort(final C c, final short value) {
		unsafe.putShort(c, offset, value);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static Unsafe getUnsafe() {
		try {
			Field field = Unsafe.class.getDeclaredField("theUnsafe");
			field.setAccessible(true);
			return (Unsafe) field.get(null);
		} catch (Exception ex) {
			throw new RuntimeException("Cannot get Unsafe instance", ex);
		}
	}

	public static void main(String[] args) throws Exception {
		Profiler fieldReflection = new Profiler(20, 10000000);

		fieldReflection.add(fieldReflection.new Test("Length Method Call") {
			protected void execute(final int numIterations) {
				final int[] filler = new int[numIterations];
				final String foo = "Foo";

				start();
				for (int j=0; j < numIterations; j++) {
					filler[j] = foo.length();
				}
				end();
			}
		});

		fieldReflection.add(fieldReflection.new Test("PrimitiveField getInt()") {
			protected void execute(final int numIterations) {
				final int[] filler = new int[numIterations];
				final PrimitiveField<String> length = new PrimitiveField<String>(String.class, "count");
				final String foo = "Foo";

				start();
				for (int j=0; j < numIterations; j++) {
					filler[j] = length.getInt(foo);
				}
				end();
			}
		});

		fieldReflection.add(fieldReflection.new Test("java.lang.reflect.Field getInt()") {
			protected void execute(final int numIterations) throws Exception {
				final int[] filler = new int[numIterations];
				final Field f = String.class.getDeclaredField("count");
				f.setAccessible(true);
				final String foo = "Foo";

				start();
				for (int j=0; j < numIterations; j++) {
					filler[j] = f.getInt(foo);
				}
				end();
			}
		});

		fieldReflection.runTests();

		System.out.println(fieldReflection);

		// TODO: Now can do summations, averages, min/max, and aggregate percentage ratio comparisons
	}

}	// End FastField
