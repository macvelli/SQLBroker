package root.lang;

/**
 * Supports either building the char[] array outside and appending it or
 * getting the char[] array and working with it as needed.
 * 
 * TODO:
 * 		+ Is this really needed since ParamStrBuilder does all the same crap?
 * 
 * @author esmith
 */
public class CharArrayBuilder implements Characters {

	private char[] chars;

	public Characters append(final char c) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final char... chars) {
		this.chars = chars;
		return null;
	}

	public Characters append(final char[] str, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Iterable<?> o) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Extractable e) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Extractable e, final int firstElementIndex) {
		return null;
	}

	public Characters append(final Extractable[] e, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Object o) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Object o, final int firstElementIndex) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Object[] objs) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final Object[] objs, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	public Characters append(final String str) {
		throw new UnsupportedOperationException();
	}

	public void ensureFree(final int numChars) {
		throw new UnsupportedOperationException();
	}

	public char[] getChars(final int numCharsToAdd) {
		chars = new char[numCharsToAdd];
		return chars;
	}

	public int length() {
		return (chars == null) ? 0 : chars.length;
	}

	@Override
	public String toString() {
		// TODO: Make this Fast!
		return new String(chars, 0, chars.length);
	}

	@Override
	public Characters append(boolean b) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(double d) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(float f) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(long l) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(StringBuffer strBuf) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(StringBuilder builder) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCapacity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Characters separator(int start) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(byte[] b) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Characters append(Extractable[] e) {
		// TODO Auto-generated method stub
		return null;
	}

}	// End CharArrayBuilder
