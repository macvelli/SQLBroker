package root.lang;

public interface Immutable {

	Object toImmutable();

}
