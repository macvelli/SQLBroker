package root.lang;

// TODO: Something about this tells me it is incomplete
public interface Characters {

	public static final char[] separator = {',',' '};

	public static final char[] digits = {'0','1','2','3','4','5','6','7','8','9'};

	public static final char[] digitOnes = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        };

	public static final char[] digitTens = {
        '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
        '1', '1', '1', '1', '1', '1', '1', '1', '1', '1',
        '2', '2', '2', '2', '2', '2', '2', '2', '2', '2',
        '3', '3', '3', '3', '3', '3', '3', '3', '3', '3',
        '4', '4', '4', '4', '4', '4', '4', '4', '4', '4',
        '5', '5', '5', '5', '5', '5', '5', '5', '5', '5',
        '6', '6', '6', '6', '6', '6', '6', '6', '6', '6',
        '7', '7', '7', '7', '7', '7', '7', '7', '7', '7',
        '8', '8', '8', '8', '8', '8', '8', '8', '8', '8',
        '9', '9', '9', '9', '9', '9', '9', '9', '9', '9',
        };

	// TODO: Should I delete this crap?
	public static final char[] empty = {};

	// TODO: Should I delete this crap?
	public static final char[] emptyArray = {'[',']'};

	Characters append(boolean b);

	Characters append(byte[] b);

	Characters append(double d);

	Characters append(float f);

	Characters append(int i);

	Characters append(long l);

	Characters append(char c);

	Characters append(char... str);

	Characters append(char[] str, int offset, int count);

	Characters append(Extractable e);

	Characters append(Extractable[] e);

	Characters append(Extractable[] e, int offset, int count);

	Characters append(Object o);

	Characters append(Object[] objs);

	Characters append(Object[] objs, int offset, int count);

	Characters append(String str);

	Characters append(StringBuffer strBuf);

	Characters append(StringBuilder builder);

	void clear();

	int getCapacity();

	char[] getChars(int numCharsToAdd);

	int length();

	Characters separator(int start);

}
