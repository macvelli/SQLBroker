package root.servlet.http;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

class RequestDock implements LoadingDock {

	private final HttpServletRequest request;

	RequestDock(final HttpServletRequest request) {
		this.request = request;
	}

	public boolean contains(final String name) {
		return request.getAttribute(name) != null;
	}

	public boolean contains(final Object key) {
		return request.getAttribute(key.toString()) != null;
	}

	public Object get(final String name) {
		return request.getAttribute(name);
	}

	public Object get(final Object key) {
		return request.getAttribute(key.toString());
	}

	public void set(final String name, final Object value) {
		request.setAttribute(name, value);
	}

	public void set(final Object key, final Object value) {
		request.setAttribute(key.toString(), value);
	}

	public void remove(final String name) {
		request.removeAttribute(name);
	}

	public void remove(final Object key) {
		request.removeAttribute(key.toString());
	}

	@Override
	@SuppressWarnings("unchecked")
	public String toString() {
		String s;
		final StringBuilder builder = new StringBuilder(512);

		builder.append("HttpServletRequest ").append(request.getRequestURL()).append(" attributes:\n");
		for (Enumeration<String> e = request.getAttributeNames(); e.hasMoreElements(); ) {
			s = e.nextElement();
			builder.append(s).append('=').append(request.getAttribute(s)).append('\n');
		}

		return builder.toString();
	}

}	// End RequestDock
