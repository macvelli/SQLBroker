package root.servlet.http;

import java.util.Enumeration;

import javax.servlet.http.HttpSession;

class SessionDock implements LoadingDock {

	private final HttpSession session;

	SessionDock(final HttpSession session) {
		this.session = session;
	}

	public boolean contains(final String name) {
		return session.getAttribute(name) != null;
	}

	public boolean contains(final Object key) {
		return session.getAttribute(key.toString()) != null;
	}

	public Object get(final String name) {
		return session.getAttribute(name);
	}

	public Object get(final Object key) {
		return session.getAttribute(key.toString());
	}

	public void set(final String name, final Object value) {
		session.setAttribute(name, value);
	}

	public void set(final Object key, final Object value) {
		session.setAttribute(key.toString(), value);
	}

	public void remove(final String name) {
		session.removeAttribute(name);
	}

	public void remove(final Object key) {
		session.removeAttribute(key.toString());
	}

	@Override
	@SuppressWarnings("unchecked")
	public String toString() {
		String s;
		final StringBuilder builder = new StringBuilder(512);

		builder.append("HttpSession ").append(session.getId()).append(" attributes:\n");
		for (Enumeration<String> e = session.getAttributeNames(); e.hasMoreElements(); ) {
			s = e.nextElement();
			builder.append(s).append('=').append(session.getAttribute(s)).append('\n');
		}

		return builder.toString();
	}

}	// End SessionDock
