package root.servlet.http;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import root.data.structure.MapHashed;

class ClientDock implements LoadingDock {

	private final MapHashed<String, Cookie> attrs;
	private final HttpServletResponse response;

	ClientDock(final HttpServletRequest request, final HttpServletResponse response) {
		final Cookie[] cookies = request.getCookies();

		attrs = new MapHashed<>((cookies != null) ? cookies.length : 0);
		for (Cookie c : cookies)
			attrs.put(c.getName(), c);

		this.response = response;
	}

	public boolean contains(final String name) {
		return attrs.containsKey(name);
	}

	public boolean contains(final Object key) {
		return attrs.containsKey(key.toString());
	}

	public Object get(final String name) {
		final Cookie c = attrs.get(name);

		return (c != null) ? c.getValue() : null;
	}

	public Object get(final Object key) {
		final Cookie c = attrs.get(key.toString());

		return (c != null) ? c.getValue() : null;
	}

	public void set(final String name, final Object value) {
		Cookie c = attrs.get(name);

		if (c != null)
			c.setValue(value.toString());
		else
			c = new Cookie(name, value.toString());

		c.setPath("/");
		response.addCookie(c);
	}

	public void set(final Object key, final Object value) {
		set(key.toString(), value);
	}

	public void remove(final String name) {
		final Cookie c = attrs.get(name);

		if (c != null) {
			final Cookie remove = new Cookie(c.getName(), c.getValue());
			remove.setDomain(c.getDomain());
			remove.setPath(c.getPath());
			remove.setMaxAge(0);
			response.addCookie(remove);
		}
	}

	public void remove(final Object key) {
		remove(key.toString());
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder(512);

//		TODO: Fuck this shit and do it right
//		builder.append("Cookie attributes:\n");
//		for (Cookie c : attrs.getValues())
//			builder.append(c.getName()).append('=').append(c.getValue()).append('\n');

		return builder.toString();
	}

}	// End ClientDock
