package root.servlet.http;

public interface LoadingDock {

	public boolean contains(String name);

	public boolean contains(Object key);

	public Object get(String name);

	public Object get(Object key);

	public void set(String name, Object value);

	public void set(Object key, Object value);

	public void remove(String name);

	public void remove(Object key);

}	// End LoadingDock
