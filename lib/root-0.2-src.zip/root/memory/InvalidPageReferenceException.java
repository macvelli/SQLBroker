package root.memory;

import root.lang.ParamStr;

public class InvalidPageReferenceException extends RuntimeException {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = -8810864801748249254L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public InvalidPageReferenceException(final int pageIndex, final int pageTableSize) {
		super(ParamStr.format("PageIndex: {P} PageTable Size: {P}", pageIndex, pageTableSize));
	}

}
