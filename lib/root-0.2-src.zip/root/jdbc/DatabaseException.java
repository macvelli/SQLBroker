package root.jdbc;

import java.sql.SQLException;

/**
 * 
 * @author esmith
 */
public class DatabaseException extends RuntimeException {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 5970695279312960124L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public DatabaseException(final String message) {
		super(message);
	}

	public DatabaseException(final SQLException cause) {
		super(cause);
	}

	public DatabaseException(final String message, Throwable cause) {
		super(message, cause);
	}

}
