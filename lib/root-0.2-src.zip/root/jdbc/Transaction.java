/*
 * Open source license text goes here.
 */

package root.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import root.data.structure.MapHashed;
import root.log.Log;

/**
 * TODO:
 * 		+ Should there be something that can be called at the very end of a process to see whether or not
 * 		  an uncommitted transaction still exists, and if so throw an exception?
 * 		+ How about nested transactions?  Savepoints?
 * 
 * @author esmith
 */
public final class Transaction {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final Log log = new Log(Transaction.class);

	private static final MapHashed<Thread, TransactionLocalScope> txnMap = new MapHashed<>();

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * Begins a transaction on the current thread if one is not already in
	 * progress with the default transaction isolation level.
	 */
	public static final void begin() {
		Transaction.begin(IsolationLevel.DEFAULT);
	}

	/**
	 * Begins a transaction on the current thread if one is not already in
	 * progress.  The new transaction is created with the specified isolation
	 * level.
	 * 
	 * @param isolationLevel	The isolation level to use for the transaction.
	 */
	public static final void begin(final IsolationLevel isoLevel) {
		if (txnMap.get(Thread.currentThread()) == null) {
			log.debug("Beginning new transaction with isolation level {P}", isoLevel);
			txnMap.put(Thread.currentThread(), new TransactionLocalScope(isoLevel));
		}
	}

	/**
	 * Commits the {@link Connection} obtained from the {@link DataSource} used
	 * during the transaction.  If the {@link Connection} throws an {@link SQLException}
	 * while attempting to commit, it is repackaged into a {@link DatabaseException}
	 * and immediately rethrown.
	 * <p>
	 * A {@link DatabaseException} is thrown if <code>Transaction.begin()</code>
	 * has not been called before this method.
	 */
	public static final void commit() {
		final TransactionLocalScope txnScope = txnMap.get(Thread.currentThread());

		if (txnScope == null) {
			throw new DatabaseException("Transaction not active");
		}

		try {
			log.debug("Committing transaction");
			txnScope.commit();
		} catch (SQLException e) {
			throw new DatabaseException(e);
		} finally {
			txnMap.remove(Thread.currentThread());
		}
	}

	/**
	 * Rolls back the {@link Connection} obtained from the {@link DataSource}
	 * accessed during the transaction.  If the {@link Connection} throws an
	 * {@link SQLException} while attempting to rollback, it is repackaged
	 * into a {@link DatabaseException} and immediately rethrown.
	 * <p>
	 * A {@link DatabaseException} is thrown if <code>Transaction.begin()</code>
	 * has not been called before this method.
	 */
	public static final void rollback() {
		final TransactionLocalScope txnScope = txnMap.get(Thread.currentThread());

		if (txnScope == null) {
			throw new DatabaseException("Transaction not active");
		}

		try {
			log.debug("Rolling back transaction");
			txnScope.rollback();
		} catch (SQLException e) {
			// No-op...the connection is hosed
		} finally {
			txnMap.remove(Thread.currentThread());
		}
	}

	public static final boolean isActive() {
		return txnMap.containsKey(Thread.currentThread());
	}

	//  <><><><><><><><><><><><><>< Package Methods ><><><><><><><><><><><><><>

	/**
	 * Returns the {@link TransactionLocalScope} associated with the current
	 * thread, or <code>null</code> if a transaction is not in progress.
	 */
	static final TransactionLocalScope getLocalScope() {
		return txnMap.get(Thread.currentThread());
	}

}
